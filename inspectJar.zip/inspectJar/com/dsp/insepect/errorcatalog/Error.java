/*    */ package com.dsp.inspect.errorcatalog;
/*    */ 
/*    */ public class Error
/*    */ {
/*    */   private Integer id;
/*    */   private String name;
/*    */   private String description;
/*    */   
/*    */   public Integer getId() {
/* 10 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(Integer id) {
/* 14 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 18 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 22 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 26 */     return this.description;
/*    */   }
/*    */   
/*    */   public void setDescription(String description) {
/* 30 */     this.description = description;
/*    */   }
/*    */ }
