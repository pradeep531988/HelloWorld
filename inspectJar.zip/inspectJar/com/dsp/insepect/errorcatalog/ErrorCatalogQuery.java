/*     */ package com.dsp.inspect.errorcatalog;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import java.io.IOException;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.StatusLine;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.config.Registry;
/*     */ import org.apache.http.config.RegistryBuilder;
/*     */ import org.apache.http.conn.socket.ConnectionSocketFactory;
/*     */ import org.apache.http.conn.socket.PlainConnectionSocketFactory;
/*     */ import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
/*     */ import org.apache.http.entity.ContentType;
/*     */ import org.apache.http.entity.StringEntity;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.client.HttpClientBuilder;
/*     */ import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
/*     */ import org.apache.http.ssl.SSLContextBuilder;
/*     */ import org.apache.http.ssl.TrustStrategy;
/*     */ import org.apache.http.util.EntityUtils;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ public class ErrorCatalogQuery
/*     */ {
/*  36 */   private static final Logger log = LoggerFactory.getLogger(ErrorCatalogQuery.class);
/*     */   
/*     */ 
/*  39 */   private final ObjectMapper objectMapper = new ObjectMapper();
/*     */   private final HttpClientBuilder httpClientBuilder;
/*     */   private final String url;
/*     */   
/*     */   public ErrorCatalogQuery(String url)
/*     */     throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException
/*     */   {
/*  46 */     this.url = url;
/*  47 */     this.objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
/*     */     
/*  49 */     this.httpClientBuilder = HttpClientBuilder.create();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  54 */     SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
/*     */       public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
/*  52 */         return true;
/*     */       }
/*  54 */     }).build();
/*  55 */     this.httpClientBuilder.setSslcontext(sslContext);
/*  56 */     HostnameVerifier hostnameVerifier = SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;
/*     */     
/*  58 */     SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);
/*     */     
/*     */ 
/*     */ 
/*  62 */     Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.create().register("http", PlainConnectionSocketFactory.getSocketFactory()).register("https", sslSocketFactory).build();
/*     */     
/*  64 */     PoolingHttpClientConnectionManager connMgr = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
/*  65 */     this.httpClientBuilder.setConnectionManager(connMgr);
/*     */   }
/*     */   
/*     */ 
/*     */   public Boolean check(String appName, Error[] errors, String layer)
/*     */     throws IOException
/*     */   {
/*  72 */     log.info("Start to retrieve error catalog from remote: {} for {} with systemEvents({})", new Object[] { this.url, appName, Integer.valueOf(errors.length) });
/*  73 */     if ((errors == null) || (errors.length == 0)) {
/*  74 */       return Boolean.valueOf(false);
/*     */     }
/*  76 */     ErrorSet errorSet = new ErrorSet();
/*  77 */     errorSet.setName(appName);
/*  78 */     errorSet.setErrors(errors);
/*  79 */     errorSet.setLayer(layer);
/*  80 */     ErrorCatalogResult result = check(errorSet);
/*  81 */     log.info("Retrieve of error catalog is done with msg ({})", result.getMessage());
/*     */     
/*  83 */     return result.isSuccess();
/*     */   }
/*     */   
/*     */   private ErrorCatalogResult check(ErrorSet errorSet)
/*     */   {
/*  88 */     CloseableHttpClient httpClient = this.httpClientBuilder.build();
/*     */     
/*  90 */     HttpPost httpPost = new HttpPost(this.url);
/*     */     
/*  92 */     result = null;
/*     */     try
/*     */     {
/*  95 */       String content = this.objectMapper.writeValueAsString(errorSet);
/*     */       
/*  97 */       httpPost.setEntity(new StringEntity(content, ContentType.APPLICATION_JSON));
/*     */       
/*  99 */       HttpResponse response = httpClient.execute(httpPost);
/* 100 */       StatusLine statusLine = response.getStatusLine();
/*     */       
/* 102 */       if (statusLine.getStatusCode() >= 400) {
/* 103 */         return null;
/*     */       }
/*     */       
/* 106 */       HttpEntity respEntity = response.getEntity();
/* 107 */       result = (ErrorCatalogResult)this.objectMapper.readValue(respEntity.getContent(), ErrorCatalogResult.class);
/*     */       
/* 109 */       EntityUtils.consume(respEntity);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */       return result;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 113 */       log.error("Failed to check the error catalog", e);
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 119 */         httpClient.close();
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 123 */         log.error("Failed to close the connection", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

