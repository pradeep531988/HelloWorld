/*    */package com.dsp.inspect.errorcatalog;
/*    */ 
/*    */ public class ErrorCatalogResult
/*    */ {
/*    */   private Boolean success;
/*    */   private String message;
/*    */   
/*    */   public Boolean isSuccess() {
/*  9 */     return this.success;
/*    */   }
/*    */   
/*    */   public void setSuccess(Boolean success) {
/* 13 */     this.success = success;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 17 */     return this.message;
/*    */   }
/*    */   
/*    */   public void setMessage(String message) {
/* 21 */     this.message = message;
/*    */   }
/*    */ }

