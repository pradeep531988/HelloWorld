/*    */package com.dsp.inspect.errorcatalog;
/*    */ 
/*    */ public class ErrorSet
/*    */ {
/*    */   private String name;
/*    */   private Error[] errors;
/*    */   private String layer;
/*    */   
/*    */   public String getName()
/*    */   {
/* 11 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 15 */     this.name = name;
/*    */   }
/*    */   
/*    */   public Error[] getErrors() {
/* 19 */     return this.errors;
/*    */   }
/*    */   
/*    */   public void setErrors(Error[] errors) {
/* 23 */     this.errors = errors;
/*    */   }
/*    */   
/*    */   public String getLayer() {
/* 27 */     return this.layer;
/*    */   }
/*    */   
/*    */   public void setLayer(String layer) {
/* 31 */     this.layer = layer;
/*    */   }
/*    */ }

