/*    */ package com.dsp.inspect.errorcatalog;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.security.KeyManagementException;
/*    */ import java.security.KeyStoreException;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ 
/*    */ public class Inspector
/*    */ {
/*    */   private SystemEventRetriever retriever;
/*    */   private ErrorCatalogQuery query;
/*    */   
/*    */   public void setRetriever(SystemEventRetriever retriever)
/*    */   {
/* 16 */     this.retriever = retriever;
/*    */   }
/*    */   
/*    */   public void setQuery(ErrorCatalogQuery query) {
/* 20 */     this.query = query;
/*    */   }
/*    */   
/*    */   public Inspector(String url) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
/* 24 */     this.retriever = new SystemEventRetriever();
/* 25 */     this.query = new ErrorCatalogQuery(url);
/*    */   }
/*    */   
/*    */   public Boolean inspect(String appName, String appJarsPaths, String errorClassName, String layer, boolean scalaCodeBase) throws ClassNotFoundException, IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException
/*    */   {
/* 30 */     Error[] errors = scalaCodeBase ? this.retriever.retrieveForScala(appJarsPaths, errorClassName) : this.retriever.retrieve(appJarsPaths, errorClassName);
/*    */     
/* 32 */     return this.query.check(appName, errors, layer);
/*    */   }
/*    */ }

