/*    */ package com.dsp.inspect.errorcatalog;
/*    */ 
/*    */ import scala.reflect.api.Symbols.SymbolApi;
/*    */ 
/*    */ public final class ScalaRetriever$ {
/*    */   public static final  MODULE$;
/*    */   
/*  8 */   private ScalaRetriever$() { MODULE$ = this; }
/*    */   
/*    */   public Error[] retrieve(java.net.URL[] urls, String className) {
/* 11 */     java.net.URLClassLoader classLoader = java.net.URLClassLoader.newInstance(urls, getClass().getClassLoader());
/* 12 */     Class clazz = classLoader.loadClass(new scala.collection.mutable.StringBuilder().append(className).append("$").toString());
/*    */     
/* 14 */     Object[] eventValues = getEventValues(clazz);
/* 15 */     scala.runtime.ObjectRef errors = new scala.runtime.ObjectRef((Error[])scala.Array..MODULE$.apply(scala.collection.immutable.Nil..MODULE$, scala.reflect.ClassTag..MODULE$.apply(Error.class)));
/* 16 */     scala.Predef..MODULE$.genericArrayOps(eventValues).foreach(new scala.runtime.AbstractFunction1() {
/* 17 */       public final void apply(Object eventValue) { scala.Tuple3 localTuple32 = ScalaRetriever..MODULE$.getEventValue(eventValue); if (localTuple32 != null) { int id = scala.runtime.BoxesRunTime.unboxToInt(localTuple32._1());String name = (String)localTuple32._2();String description = (String)localTuple32._3();scala.Tuple3 localTuple33 = new scala.Tuple3(scala.runtime.BoxesRunTime.boxToInteger(id), name, description);scala.Tuple3 localTuple31 = localTuple33;int id = scala.runtime.BoxesRunTime.unboxToInt(localTuple31._1());String name = (String)localTuple31._2();String description = (String)localTuple31._3();
/* 18 */           Error error = new Error();
/* 19 */           error.setId(scala.Predef..MODULE$.int2Integer(id));
/* 20 */           error.setName(name);
/* 21 */           error.setDescription(description);
/* 22 */           this.errors$1.elem = ((Error[])scala.Predef..MODULE$.refArrayOps((Object[])this.errors$1.elem).$colon$plus(error, scala.Array..MODULE$.canBuildFrom(scala.reflect.ClassTag..MODULE$.apply(Error.class))));
/*    */         }
/*    */         else
/*    */         {
/* 17 */           throw new scala.MatchError(localTuple32);
/*    */ 
/*    */         }
/*    */         
/*    */       }
/*    */       
/*    */ 
/* 24 */     });
/* 25 */     return (Error[])errors.elem; }
/*    */   
/*    */   public static final long serialVersionUID = 0L;
/*    */   private final scala.runtime.ObjectRef errors$1;
/* 29 */   public Object[] getEventValues(Class<?> clazz) { null;Object eventObject = clazz.getField("MODULE$").get(null);
/* 30 */     scala.reflect.api.JavaMirrors.JavaMirror cm = scala.reflect.runtime.package..MODULE$.universe().runtimeMirror(getClass().getClassLoader());
/* 31 */     scala.collection.Iterable accessors = (scala.collection.Iterable)((scala.reflect.api.Symbols.TypeSymbolApi)cm.classSymbol(eventObject.getClass())).toType().members().collect(new scala.runtime.AbstractPartialFunction() { public final boolean isDefinedAt(Symbols.SymbolApi x2) { Symbols.SymbolApi localSymbolApi = x2;
/* 32 */         scala.Option localOption = ((scala.reflect.api.Symbols)scala.reflect.runtime.package..MODULE$.universe()).MethodSymbolTag().unapply(localSymbolApi); boolean bool; if ((!localOption.isEmpty()) && (localOption.get() != null) && (((scala.reflect.api.Symbols.TermSymbolApi)localSymbolApi).isGetter()) && (((Symbols.SymbolApi)localSymbolApi).isPublic())) { bool = true;
/*    */         } else
/* 31 */           bool = false; return bool; } public final <A1 extends Symbols.SymbolApi, B1> B1 applyOrElse(A1 x2, scala.Function1<A1, B1> default) { Symbols.SymbolApi localSymbolApi = x2;
/* 32 */         scala.Option localOption = ((scala.reflect.api.Symbols)scala.reflect.runtime.package..MODULE$.universe()).MethodSymbolTag().unapply(localSymbolApi); Object localObject; if ((!localOption.isEmpty()) && (localOption.get() != null) && (((scala.reflect.api.Symbols.TermSymbolApi)localSymbolApi).isGetter()) && (((Symbols.SymbolApi)localSymbolApi).isPublic())) { localObject = localSymbolApi;
/*    */         } else
/* 31 */           localObject = default.apply(x2); return (B1)localObject; } }, scala.collection.Iterable..MODULE$.canBuildFrom());
/*    */     
/*    */ 
/* 34 */     scala.reflect.api.Mirrors.InstanceMirror instanceMirror = cm.reflect(eventObject, scala.reflect.ClassTag..MODULE$.Object());
/* 35 */     final scala.runtime.ObjectRef result = new scala.runtime.ObjectRef((Object[])scala.Array..MODULE$.apply(scala.collection.immutable.Nil..MODULE$, scala.reflect.ClassTag..MODULE$.Any()));
/* 36 */     accessors.foreach(new scala.runtime.AbstractFunction1() {
/* 37 */       public final void apply(Symbols.SymbolApi acc) { Object eventValue = this.instanceMirror$2.reflectMethod(acc).apply(scala.collection.immutable.Nil..MODULE$);
/* 38 */         result.elem = ((Object[])scala.Predef..MODULE$.genericArrayOps((Object[])result.elem).$colon$plus(eventValue, scala.Array..MODULE$.canBuildFrom(scala.reflect.ClassTag..MODULE$.Any())));
/* 39 */       } });
/* 40 */     return (Object[])result.elem; }
/*    */   
/*    */   public static final long serialVersionUID = 0L;
/*    */   public static final long serialVersionUID = 0L;
/*    */   private final scala.reflect.api.Mirrors.InstanceMirror instanceMirror$2;
/* 45 */   public scala.Tuple3<Object, String, String> getEventValue(Object event) { scala.runtime.IntRef id = new scala.runtime.IntRef(0);
/* 46 */     final scala.runtime.ObjectRef name = new scala.runtime.ObjectRef("");
/* 47 */     final scala.runtime.ObjectRef description = new scala.runtime.ObjectRef("");
/*    */     
/* 49 */     scala.reflect.api.JavaMirrors.JavaMirror cm = scala.reflect.runtime.package..MODULE$.universe().runtimeMirror(getClass().getClassLoader());
/* 50 */     scala.collection.Iterable accessors = (scala.collection.Iterable)((scala.reflect.api.Symbols.TypeSymbolApi)cm.classSymbol(event.getClass())).toType().members().collect(new scala.runtime.AbstractPartialFunction() { public final boolean isDefinedAt(Symbols.SymbolApi x1) { Symbols.SymbolApi localSymbolApi = x1;
/* 51 */         scala.Option localOption = ((scala.reflect.api.Symbols)scala.reflect.runtime.package..MODULE$.universe()).MethodSymbolTag().unapply(localSymbolApi); boolean bool; if ((!localOption.isEmpty()) && (localOption.get() != null) && (((scala.reflect.api.Symbols.TermSymbolApi)localSymbolApi).isGetter()) && (((Symbols.SymbolApi)localSymbolApi).isPublic())) { bool = true;
/*    */         } else
/* 50 */           bool = false; return bool; } public final <A1 extends Symbols.SymbolApi, B1> B1 applyOrElse(A1 x1, scala.Function1<A1, B1> default) { Symbols.SymbolApi localSymbolApi = x1;
/* 51 */         scala.Option localOption = ((scala.reflect.api.Symbols)scala.reflect.runtime.package..MODULE$.universe()).MethodSymbolTag().unapply(localSymbolApi); Object localObject; if ((!localOption.isEmpty()) && (localOption.get() != null) && (((scala.reflect.api.Symbols.TermSymbolApi)localSymbolApi).isGetter()) && (((Symbols.SymbolApi)localSymbolApi).isPublic())) { localObject = localSymbolApi;
/*    */         } else
/* 50 */           localObject = default.apply(x1); return (B1)localObject; } }, scala.collection.Iterable..MODULE$.canBuildFrom());
/*    */     
/*    */ 
/* 53 */     final scala.reflect.api.Mirrors.InstanceMirror instanceMirror = cm.reflect(event, scala.reflect.ClassTag..MODULE$.Any());
/* 54 */     accessors.foreach(new scala.runtime.AbstractFunction1()
/*    */     {
/*    */       public static final long serialVersionUID = 0L;
/*    */       public static final long serialVersionUID = 0L;
/*    */       private final scala.runtime.IntRef id$1;
/*    */       
/*    */       /* Error */
/*    */       public final void apply(Symbols.SymbolApi acc)
/*    */       {
/*    */         // Byte code:
/*    */         //   0: aload_0
/*    */         //   1: getfield 28	com/expedia/prime/errorcatalog/ScalaRetriever$$anonfun$getEventValue$1:instanceMirror$1	Lscala/reflect/api/Mirrors$InstanceMirror;
/*    */         //   4: aload_1
/*    */         //   5: invokeinterface 34 2 0
/*    */         //   10: getstatic 40	scala/collection/immutable/Nil$:MODULE$	Lscala/collection/immutable/Nil$;
/*    */         //   13: invokeinterface 45 2 0
/*    */         //   18: astore_2
/*    */         //   19: aload_1
/*    */         //   20: invokeinterface 51 1 0
/*    */         //   25: invokevirtual 57	java/lang/Object:toString	()Ljava/lang/String;
/*    */         //   28: astore_3
/*    */         //   29: aload_3
/*    */         //   30: astore 4
/*    */         //   32: ldc 59
/*    */         //   34: aload 4
/*    */         //   36: astore 5
/*    */         //   38: dup
/*    */         //   39: ifnonnull +12 -> 51
/*    */         //   42: pop
/*    */         //   43: aload 5
/*    */         //   45: ifnull +14 -> 59
/*    */         //   48: goto +46 -> 94
/*    */         //   51: aload 5
/*    */         //   53: invokevirtual 63	java/lang/Object:equals	(Ljava/lang/Object;)Z
/*    */         //   56: ifeq +38 -> 94
/*    */         //   59: aload_0
/*    */         //   60: getfield 65	com/expedia/prime/errorcatalog/ScalaRetriever$$anonfun$getEventValue$1:id$1	Lscala/runtime/IntRef;
/*    */         //   63: new 67	scala/collection/immutable/StringOps
/*    */         //   66: dup
/*    */         //   67: getstatic 72	scala/Predef$:MODULE$	Lscala/Predef$;
/*    */         //   70: aload_2
/*    */         //   71: invokevirtual 57	java/lang/Object:toString	()Ljava/lang/String;
/*    */         //   74: invokevirtual 76	scala/Predef$:augmentString	(Ljava/lang/String;)Ljava/lang/String;
/*    */         //   77: invokespecial 80	scala/collection/immutable/StringOps:<init>	(Ljava/lang/String;)V
/*    */         //   80: invokevirtual 84	scala/collection/immutable/StringOps:toInt	()I
/*    */         //   83: putfield 90	scala/runtime/IntRef:elem	I
/*    */         //   86: getstatic 96	scala/runtime/BoxedUnit:UNIT	Lscala/runtime/BoxedUnit;
/*    */         //   89: astore 6
/*    */         //   91: goto +92 -> 183
/*    */         //   94: ldc 97
/*    */         //   96: aload 4
/*    */         //   98: astore 7
/*    */         //   100: dup
/*    */         //   101: ifnonnull +12 -> 113
/*    */         //   104: pop
/*    */         //   105: aload 7
/*    */         //   107: ifnull +14 -> 121
/*    */         //   110: goto +30 -> 140
/*    */         //   113: aload 7
/*    */         //   115: invokevirtual 63	java/lang/Object:equals	(Ljava/lang/Object;)Z
/*    */         //   118: ifeq +22 -> 140
/*    */         //   121: aload_0
/*    */         //   122: getfield 99	com/expedia/prime/errorcatalog/ScalaRetriever$$anonfun$getEventValue$1:name$1	Lscala/runtime/ObjectRef;
/*    */         //   125: aload_2
/*    */         //   126: invokevirtual 57	java/lang/Object:toString	()Ljava/lang/String;
/*    */         //   129: putfield 104	scala/runtime/ObjectRef:elem	Ljava/lang/Object;
/*    */         //   132: getstatic 96	scala/runtime/BoxedUnit:UNIT	Lscala/runtime/BoxedUnit;
/*    */         //   135: astore 6
/*    */         //   137: goto +46 -> 183
/*    */         //   140: ldc 106
/*    */         //   142: aload 4
/*    */         //   144: astore 8
/*    */         //   146: dup
/*    */         //   147: ifnonnull +12 -> 159
/*    */         //   150: pop
/*    */         //   151: aload 8
/*    */         //   153: ifnull +14 -> 167
/*    */         //   156: goto +28 -> 184
/*    */         //   159: aload 8
/*    */         //   161: invokevirtual 63	java/lang/Object:equals	(Ljava/lang/Object;)Z
/*    */         //   164: ifeq +20 -> 184
/*    */         //   167: aload_0
/*    */         //   168: getfield 108	com/expedia/prime/errorcatalog/ScalaRetriever$$anonfun$getEventValue$1:description$1	Lscala/runtime/ObjectRef;
/*    */         //   171: aload_2
/*    */         //   172: invokevirtual 57	java/lang/Object:toString	()Ljava/lang/String;
/*    */         //   175: putfield 104	scala/runtime/ObjectRef:elem	Ljava/lang/Object;
/*    */         //   178: getstatic 96	scala/runtime/BoxedUnit:UNIT	Lscala/runtime/BoxedUnit;
/*    */         //   181: astore 6
/*    */         //   183: return
/*    */         //   184: new 110	scala/MatchError
/*    */         //   187: dup
/*    */         //   188: aload 4
/*    */         //   190: invokespecial 113	scala/MatchError:<init>	(Ljava/lang/Object;)V
/*    */         //   193: athrow
/*    */         // Line number table:
/*    */         //   Java source line #55	-> byte code offset #0
/*    */         //   Java source line #56	-> byte code offset #19
/*    */         //   Java source line #58	-> byte code offset #29
/*    */         //   Java source line #59	-> byte code offset #32
/*    */         //   Java source line #60	-> byte code offset #94
/*    */         //   Java source line #61	-> byte code offset #140
/*    */         //   Java source line #54	-> byte code offset #183
/*    */         //   Java source line #58	-> byte code offset #184
/*    */         // Local variable table:
/*    */         //   start	length	slot	name	signature
/*    */         //   0	194	0	this	1
/*    */         //   0	194	1	acc	Symbols.SymbolApi
/*    */         //   19	175	2	field	Object
/*    */         //   29	165	3	fieldName	String
/*    */       }
/* 63 */     });
/* 64 */     return new scala.Tuple3(scala.runtime.BoxesRunTime.boxToInteger(id.elem), (String)name.elem, (String)description.elem);
/*    */   }
/*    */   
/*    */   static
/*    */   {
/*    */     new ();
/*    */   }
/*    */ }

