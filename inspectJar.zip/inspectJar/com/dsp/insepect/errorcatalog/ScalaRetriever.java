package com.dsp.inspect.errorcatalog;
import java.net.URL;
import scala.Tuple3;
import scala.reflect.ScalaSignature;

@ScalaSignature(bytes="\006\001m;Q!\001\002\t\002-\tabU2bY\006\024V\r\036:jKZ,'O\003\002\004\t\005aQM\035:pe\016\fG/\0317pO*\021QAB\001\006aJLW.\032\006\003\017!\tq!\032=qK\022L\027MC\001\n\003\r\031w.\\\002\001!\taQ\"D\001\003\r\025q!\001#\001\020\0059\0316-\0317b%\026$(/[3wKJ\034\"!\004\t\021\005E!R\"\001\n\013\003M\tQa]2bY\006L!!\006\n\003\r\005s\027PU3g\021\0259R\002\"\001\031\003\031a\024N\\5u}Q\t1\002C\003\033\033\021\0051$\001\005sKR\024\030.\032<f)\ra\"%\f\t\004#uy\022B\001\020\023\005\025\t%O]1z!\ta\001%\003\002\"\005\t)QI\035:pe\")1%\007a\001I\005!QO\0357t!\r\tR$\n\t\003M-j\021a\n\006\003Q%\n1A\\3u\025\005Q\023\001\0026bm\006L!\001L\024\003\007U\023F\nC\003/3\001\007q&A\005dY\006\0348OT1nKB\021\001g\r\b\003#EJ!A\r\n\002\rA\023X\rZ3g\023\t!TG\001\004TiJLgn\032\006\003eIAQaN\007\005\002a\nabZ3u\013Z,g\016\036,bYV,7\017\006\002:{A\031\021#\b\036\021\005EY\024B\001\037\023\005\r\te.\037\005\006}Y\002\raP\001\006G2\f'P\037\031\003\001\026\0032\001M!D\023\t\021UGA\003DY\006\0348\017\005\002E\0132\001A!\003$>\003\003\005\tQ!\001H\005\ryF%M\t\003\021j\002\"!E%\n\005)\023\"a\002(pi\"Lgn\032\005\006\0316!\t!T\001\016O\026$XI^3oiZ\013G.^3\025\0059K\006#B\tP#R#\026B\001)\023\005\031!V\017\0357fgA\021\021CU\005\003'J\0211!\0238u!\t)\006,D\001W\025\t9\026&\001\003mC:<\027B\001\033W\021\025Q6\n1\001;\003\025)g/\0328u\001")
public final class ScalaRetriever
{
  public static Tuple3<Object, String, String> getEventValue(Object paramObject)
  {
    return ScalaRetriever..MODULE$.getEventValue(paramObject);
  }
  
  public static Object[] getEventValues(Class<?> paramClass)
  {
    return ScalaRetriever..MODULE$.getEventValues(paramClass);
  }
  
  public static Error[] retrieve(URL[] paramArrayOfURL, String paramString)
  {
    return ScalaRetriever..MODULE$.retrieve(paramArrayOfURL, paramString);
  }
}

