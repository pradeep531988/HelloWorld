/*     */ package com.dsp.inspect.errorcatalog;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.nio.file.DirectoryStream;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import org.apache.commons.cli.CommandLine;
/*     */ import org.apache.commons.cli.CommandLineParser;
/*     */ import org.apache.commons.cli.DefaultParser;
/*     */ import org.apache.commons.cli.HelpFormatter;
/*     */ import org.apache.commons.cli.Options;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ 
/*     */ @org.springframework.boot.autoconfigure.EnableAutoConfiguration
/*     */ public class Starter
/*     */ {
/*  20 */   private static final Logger log = LoggerFactory.getLogger(Starter.class);
/*     */   
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*  25 */     int test = 0;
/*  26 */     System.out.println("Starting ... " + java.util.Arrays.toString(args));
/*     */     
/*  28 */     SpringApplication.run(Starter.class, new String[0]);
/*     */     
/*  30 */     CommandLineParser parser = new DefaultParser();
/*  31 */     Options options = new Options();
/*  32 */     options.addOption("a", "appname", true, "application name");
/*  33 */     options.addOption("l", "layer", true, "specify ExpWeb Layer");
/*  34 */     options.addOption("u", "url", true, "endpoint of error-catalog service");
/*  35 */     options.addOption("j", "appjarsurl", true, "urls of jars or classpaths that contain system events (separated by ',')");
/*  36 */     options.addOption("p", "appjarspath", true, "path of jars or classpaths that contain system events (separated by ',')");
/*  37 */     options.addOption("c", "classname", true, "full class name of system event");
/*  38 */     options.addOption("s", "scala", false, "from scala codebase");
/*  39 */     options.addOption("h", "help", false, "show the usage");
/*     */     
/*  41 */     CommandLine line = parser.parse(options, args);
/*     */     
/*  43 */     String appName = "";
/*  44 */     String layer = null;
/*  45 */     String url = "";
/*  46 */     String jarUrls = "";
/*  47 */     String jarPaths = "";
/*  48 */     String className = "";
/*  49 */     boolean fromScala = false;
/*     */     
/*  51 */     if (line.hasOption("a")) {
/*  52 */       appName = line.getOptionValue("a");
/*     */     }
/*     */     
/*  55 */     if (line.hasOption("l")) {
/*  56 */       layer = line.getOptionValue("l");
/*     */     }
/*     */     
/*  59 */     if (line.hasOption("u")) {
/*  60 */       url = line.getOptionValue("u");
/*     */     }
/*     */     
/*  63 */     if (line.hasOption("j")) {
/*  64 */       jarUrls = line.getOptionValue("j");
/*     */     }
/*     */     
/*  67 */     if (line.hasOption("p")) {
/*  68 */       jarPaths = line.getOptionValue("p");
/*     */     }
/*     */     
/*  71 */     if (line.hasOption("c")) {
/*  72 */       className = line.getOptionValue("c");
/*     */     }
/*     */     
/*  75 */     if (line.hasOption("s")) {
/*  76 */       fromScala = true;
/*     */     }
/*     */     
/*  79 */     if (line.hasOption("h")) {
/*  80 */       printHelp(options);
/*  81 */       System.exit(0);
/*     */     }
/*     */     
/*  84 */     Inspector inspector = new Inspector(url);
/*     */     
/*     */ 
/*  87 */     if (!org.apache.commons.lang3.StringUtils.isEmpty(jarPaths)) {
/*  88 */       jarUrls = convert2Urls(jarPaths);
/*     */     }
/*     */     
/*  91 */     if (inspector.inspect(appName, jarUrls, className, layer, fromScala).booleanValue()) {
/*  92 */       log.info("Errors definition has passed the inspection!!!");
/*     */     } else {
/*  94 */       log.error("Some error(s) may not be defined");
/*  95 */       System.exit(1);
/*     */     }
/*     */     
/*     */ 
/*  99 */     log.info("Completed.");
/*     */   }
/*     */   
/*     */   private static void printHelp(Options options) {
/* 103 */     HelpFormatter formatter = new HelpFormatter();
/* 104 */     formatter.printHelp("java -jar error-inspector.jar", options);
/*     */   }
/*     */   
/*     */   private static String convert2Urls(String jarPaths) throws java.io.IOException
/*     */   {
/* 109 */     String[] holder = jarPaths.split(",");
/* 110 */     StringBuilder result = new StringBuilder();
/* 111 */     for (String pathStr : holder)
/*     */     {
/* 113 */       if (pathStr.endsWith("*.jar")) {
/* 114 */         DirectoryStream<Path> directoryStream = Files.newDirectoryStream(Paths.get(pathStr.substring(0, pathStr.length() - 5), new String[0]));Throwable localThrowable3 = null;
/* 115 */         try { for (Path elem : directoryStream) {
/* 116 */             result.append(convertPath2Url(elem.toString())).append(",");
/*     */           }
/*     */         }
/*     */         catch (Throwable localThrowable5)
/*     */         {
/* 114 */           localThrowable3 = localThrowable5;throw localThrowable5;
/*     */         }
/*     */         finally
/*     */         {
/* 118 */           if (directoryStream != null) if (localThrowable3 != null) try { directoryStream.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else directoryStream.close();
/*     */         }
/* 120 */       } else { result.append(convertPath2Url(pathStr)).append(",");
/*     */       }
/*     */     }
/* 123 */     result.deleteCharAt(result.length() - 1);
/* 124 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static String convertPath2Url(String pathStr) throws MalformedURLException {
/* 128 */     Path path = Paths.get(pathStr, new String[0]);
/* 129 */     return path.toUri().toURL().toString();
/*     */   }
/*     */ }
