/*    */ package com.dsp.inspect.errorcatalog;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import java.net.URLClassLoader;
/*    */ import java.util.ArrayList;
/*    */ import org.slf4j.Logger;
/*    */ 
/*    */ public class SystemEventRetriever
/*    */ {
/* 13 */   private static final Logger log = org.slf4j.LoggerFactory.getLogger(SystemEventRetriever.class);
/*    */   
/*    */   public Error[] retrieveForScala(String appJarsPaths, String errorClassName) throws MalformedURLException, ClassNotFoundException
/*    */   {
/* 17 */     log.info("Start to retrieve system events defined in scala codebase from the app package");
/* 18 */     return ScalaRetriever.retrieve(parseUrls(appJarsPaths), errorClassName);
/*    */   }
/*    */   
/*    */   public Error[] retrieve(String appJarsPaths, String errorClassName)
/*    */     throws MalformedURLException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException
/*    */   {
/* 24 */     log.info("Start to retrieve system events from the app package");
/* 25 */     ClassLoader loader = URLClassLoader.newInstance(
/* 26 */       parseUrls(appJarsPaths), getClass().getClassLoader());
/* 27 */     Class<?> eventClass = Class.forName(errorClassName, true, loader);
/*    */     
/* 29 */     Method idMethod = null;
/*    */     try {
/* 31 */       idMethod = eventClass.getMethod("getId", new Class[0]);
/*    */     } catch (NoSuchMethodException e) {
/* 33 */       idMethod = eventClass.getMethod("getEventId", new Class[0]);
/*    */     }
/* 35 */     Method nameMethod = null;
/*    */     try {
/* 37 */       nameMethod = eventClass.getMethod("name", new Class[0]);
/*    */     } catch (NoSuchMethodException e) {
/* 39 */       nameMethod = eventClass.getMethod("getName", new Class[0]);
/*    */     }
/* 41 */     Method descMethod = eventClass.getMethod("getDescription", new Class[0]);
/*    */     
/* 43 */     Object[] enums = eventClass.getEnumConstants();
/* 44 */     ArrayList<Error> result = new ArrayList();
/*    */     
/* 46 */     for (Object e : enums) {
/* 47 */       Error error = new Error();
/* 48 */       error.setId((Integer)idMethod.invoke(e, new Object[0]));
/* 49 */       error.setName((String)nameMethod.invoke(e, new Object[0]));
/* 50 */       error.setDescription((String)descMethod.invoke(e, new Object[0]));
/* 51 */       result.add(error);
/*    */     }
/*    */     
/* 54 */     log.info("Retrieve of system events is done");
/* 55 */     return (Error[])result.toArray(new Error[0]);
/*    */   }
/*    */   
/*    */   private URL[] parseUrls(String urls) throws MalformedURLException {
/* 59 */     String[] holder = urls.split(",");
/* 60 */     ArrayList<URL> result = new ArrayList();
/* 61 */     for (String url : holder) {
/* 62 */       result.add(new URL(url));
/*    */     }
/* 64 */     return (URL[])result.toArray(new URL[0]);
/*    */   }
/*    */ }

