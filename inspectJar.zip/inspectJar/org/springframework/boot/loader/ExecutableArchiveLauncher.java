/*     */ package org.springframework.boot.loader;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.loader.archive.Archive;
/*     */ import org.springframework.boot.loader.archive.Archive.Entry;
/*     */ import org.springframework.boot.loader.archive.Archive.EntryFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ExecutableArchiveLauncher
/*     */   extends Launcher
/*     */ {
/*     */   private final Archive archive;
/*     */   private final JavaAgentDetector javaAgentDetector;
/*     */   
/*     */   public ExecutableArchiveLauncher()
/*     */   {
/*  45 */     this(new InputArgumentsJavaAgentDetector());
/*     */   }
/*     */   
/*     */   public ExecutableArchiveLauncher(JavaAgentDetector javaAgentDetector) {
/*     */     try {
/*  50 */       this.archive = createArchive();
/*     */     }
/*     */     catch (Exception ex) {
/*  53 */       throw new IllegalStateException(ex);
/*     */     }
/*  55 */     this.javaAgentDetector = javaAgentDetector;
/*     */   }
/*     */   
/*     */   ExecutableArchiveLauncher(Archive archive) {
/*  59 */     this.javaAgentDetector = new InputArgumentsJavaAgentDetector();
/*  60 */     this.archive = archive;
/*     */   }
/*     */   
/*     */   protected final Archive getArchive() {
/*  64 */     return this.archive;
/*     */   }
/*     */   
/*     */   protected String getMainClass() throws Exception
/*     */   {
/*  69 */     return this.archive.getMainClass();
/*     */   }
/*     */   
/*     */   protected List<Archive> getClassPathArchives() throws Exception
/*     */   {
/*  74 */     List<Archive> archives = new ArrayList(this.archive.getNestedArchives(new Archive.EntryFilter()
/*     */     {
/*     */       public boolean matches(Archive.Entry entry)
/*     */       {
/*  78 */         return ExecutableArchiveLauncher.this.isNestedArchive(entry);
/*     */       }
/*  80 */     }));
/*  81 */     postProcessClassPathArchives(archives);
/*  82 */     return archives;
/*     */   }
/*     */   
/*     */   protected ClassLoader createClassLoader(URL[] urls) throws Exception
/*     */   {
/*  87 */     Set<URL> copy = new LinkedHashSet(urls.length);
/*  88 */     ClassLoader loader = getDefaultClassLoader();
/*  89 */     if ((loader instanceof URLClassLoader)) {
/*  90 */       for (URL url : ((URLClassLoader)loader).getURLs()) {
/*  91 */         if (addDefaultClassloaderUrl(urls, url)) {
/*  92 */           copy.add(url);
/*     */         }
/*     */       }
/*     */     }
/*  96 */     Collections.addAll(copy, urls);
/*  97 */     return super.createClassLoader((URL[])copy.toArray(new URL[copy.size()]));
/*     */   }
/*     */   
/*     */   private boolean addDefaultClassloaderUrl(URL[] urls, URL url) {
/* 101 */     String jarUrl = "jar:" + url + "!/";
/* 102 */     for (URL nestedUrl : urls) {
/* 103 */       if ((nestedUrl.equals(url)) || (nestedUrl.toString().equals(jarUrl))) {
/* 104 */         return false;
/*     */       }
/*     */     }
/* 107 */     return !this.javaAgentDetector.isJavaAgentJar(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean isNestedArchive(Archive.Entry paramEntry);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void postProcessClassPathArchives(List<Archive> archives)
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getDefaultClassLoader()
/*     */   {
/* 128 */     ClassLoader classloader = null;
/*     */     try {
/* 130 */       classloader = Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */     catch (Throwable ex) {}
/*     */     
/*     */ 
/*     */ 
/* 136 */     if (classloader == null)
/*     */     {
/* 138 */       classloader = ExecutableArchiveLauncher.class.getClassLoader();
/*     */     }
/* 140 */     return classloader;
/*     */   }
/*     */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\ExecutableArchiveLauncher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */