/*    */ package org.springframework.boot.loader;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.lang.management.ManagementFactory;
/*    */ import java.lang.management.RuntimeMXBean;
/*    */ import java.net.URI;
/*    */ import java.net.URL;
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputArgumentsJavaAgentDetector
/*    */   implements JavaAgentDetector
/*    */ {
/*    */   private static final String JAVA_AGENT_PREFIX = "-javaagent:";
/*    */   private final Set<URL> javaAgentJars;
/*    */   
/*    */   public InputArgumentsJavaAgentDetector()
/*    */   {
/* 44 */     this(getInputArguments());
/*    */   }
/*    */   
/*    */   InputArgumentsJavaAgentDetector(List<String> inputArguments) {
/* 48 */     this.javaAgentJars = getJavaAgentJars(inputArguments);
/*    */   }
/*    */   
/*    */   private static List<String> getInputArguments() {
/*    */     try {
/* 53 */       (List)AccessController.doPrivileged(new PrivilegedAction()
/*    */       {
/*    */         public List<String> run() {
/* 56 */           return ManagementFactory.getRuntimeMXBean().getInputArguments();
/*    */         }
/*    */       });
/*    */     }
/*    */     catch (Exception ex) {}
/* 61 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   private Set<URL> getJavaAgentJars(List<String> inputArguments)
/*    */   {
/* 66 */     Set<URL> javaAgentJars = new HashSet();
/* 67 */     for (String argument : inputArguments) {
/* 68 */       String path = getJavaAgentJarPath(argument);
/* 69 */       if (path != null) {
/*    */         try {
/* 71 */           javaAgentJars.add(new File(path).getCanonicalFile().toURI().toURL());
/*    */         }
/*    */         catch (IOException ex) {
/* 74 */           throw new IllegalStateException("Failed to determine canonical path of Java agent at path '" + path + "'");
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 80 */     return javaAgentJars;
/*    */   }
/*    */   
/*    */   private String getJavaAgentJarPath(String arg) {
/* 84 */     if (arg.startsWith("-javaagent:")) {
/* 85 */       String path = arg.substring("-javaagent:".length());
/* 86 */       int equalsIndex = path.indexOf('=');
/* 87 */       if (equalsIndex > -1) {
/* 88 */         path = path.substring(0, equalsIndex);
/*    */       }
/* 90 */       return path;
/*    */     }
/* 92 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isJavaAgentJar(URL url)
/*    */   {
/* 97 */     return this.javaAgentJars.contains(url);
/*    */   }
/*    */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\InputArgumentsJavaAgentDetector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */