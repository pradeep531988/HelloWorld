/*    */ package org.springframework.boot.loader;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.boot.loader.archive.Archive;
/*    */ import org.springframework.boot.loader.archive.Archive.Entry;
/*    */ import org.springframework.boot.loader.util.AsciiBytes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarLauncher
/*    */   extends ExecutableArchiveLauncher
/*    */ {
/* 32 */   private static final AsciiBytes LIB = new AsciiBytes("lib/");
/*    */   
/*    */   protected boolean isNestedArchive(Archive.Entry entry)
/*    */   {
/* 36 */     return (!entry.isDirectory()) && (entry.getName().startsWith(LIB));
/*    */   }
/*    */   
/*    */   protected void postProcessClassPathArchives(List<Archive> archives) throws Exception
/*    */   {
/* 41 */     archives.add(0, getArchive());
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 45 */     new JarLauncher().launch(args);
/*    */   }
/*    */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\JarLauncher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */