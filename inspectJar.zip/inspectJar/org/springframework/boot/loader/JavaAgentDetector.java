package org.springframework.boot.loader;

import java.net.URL;

public abstract interface JavaAgentDetector
{
  public abstract boolean isJavaAgentJar(URL paramURL);
}


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\JavaAgentDetector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */