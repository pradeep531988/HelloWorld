/*     */ package org.springframework.boot.loader;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import org.springframework.boot.loader.jar.Handler;
/*     */ import org.springframework.boot.loader.jar.JarFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LaunchedURLClassLoader
/*     */   extends URLClassLoader
/*     */ {
/*  39 */   private static LockProvider LOCK_PROVIDER = ;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ClassLoader rootClassLoader;
/*     */   
/*     */ 
/*     */ 
/*     */   public LaunchedURLClassLoader(URL[] urls, ClassLoader parent)
/*     */   {
/*  49 */     super(urls, parent);
/*  50 */     this.rootClassLoader = findRootClassLoader(parent);
/*     */   }
/*     */   
/*     */   private ClassLoader findRootClassLoader(ClassLoader classLoader) {
/*  54 */     while (classLoader != null) {
/*  55 */       if (classLoader.getParent() == null) {
/*  56 */         return classLoader;
/*     */       }
/*  58 */       classLoader = classLoader.getParent();
/*     */     }
/*  60 */     return null;
/*     */   }
/*     */   
/*     */   public URL getResource(String name)
/*     */   {
/*  65 */     URL url = null;
/*  66 */     if (this.rootClassLoader != null) {
/*  67 */       url = this.rootClassLoader.getResource(name);
/*     */     }
/*  69 */     return url == null ? findResource(name) : url;
/*     */   }
/*     */   
/*     */   public URL findResource(String name)
/*     */   {
/*     */     try {
/*  75 */       if ((name.equals("")) && (hasURLs())) {
/*  76 */         return getURLs()[0];
/*     */       }
/*  78 */       return super.findResource(name);
/*     */     }
/*     */     catch (IllegalArgumentException ex) {}
/*  81 */     return null;
/*     */   }
/*     */   
/*     */   public Enumeration<URL> findResources(String name)
/*     */     throws IOException
/*     */   {
/*  87 */     if ((name.equals("")) && (hasURLs())) {
/*  88 */       return Collections.enumeration(Arrays.asList(getURLs()));
/*     */     }
/*  90 */     return super.findResources(name);
/*     */   }
/*     */   
/*     */   private boolean hasURLs() {
/*  94 */     return getURLs().length > 0;
/*     */   }
/*     */   
/*     */   public Enumeration<URL> getResources(String name) throws IOException
/*     */   {
/*  99 */     if (this.rootClassLoader == null) {
/* 100 */       return findResources(name);
/*     */     }
/*     */     
/* 103 */     final Enumeration<URL> rootResources = this.rootClassLoader.getResources(name);
/* 104 */     final Enumeration<URL> localResources = findResources(name);
/*     */     
/* 106 */     new Enumeration()
/*     */     {
/*     */       public boolean hasMoreElements()
/*     */       {
/* 110 */         return (rootResources.hasMoreElements()) || (localResources.hasMoreElements());
/*     */       }
/*     */       
/*     */ 
/*     */       public URL nextElement()
/*     */       {
/* 116 */         if (rootResources.hasMoreElements()) {
/* 117 */           return (URL)rootResources.nextElement();
/*     */         }
/* 119 */         return (URL)localResources.nextElement();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> loadClass(String name, boolean resolve)
/*     */     throws ClassNotFoundException
/*     */   {
/* 131 */     synchronized (LOCK_PROVIDER.getLock(this, name)) {
/* 132 */       Class<?> loadedClass = findLoadedClass(name);
/* 133 */       if (loadedClass == null) {
/* 134 */         Handler.setUseFastConnectionExceptions(true);
/*     */         try {
/* 136 */           loadedClass = doLoadClass(name);
/*     */         }
/*     */         finally {
/* 139 */           Handler.setUseFastConnectionExceptions(false);
/*     */         }
/*     */       }
/* 142 */       if (resolve) {
/* 143 */         resolveClass(loadedClass);
/*     */       }
/* 145 */       return loadedClass;
/*     */     }
/*     */   }
/*     */   
/*     */   private Class<?> doLoadClass(String name) throws ClassNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 153 */       if (this.rootClassLoader != null) {
/* 154 */         return this.rootClassLoader.loadClass(name);
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {}
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 162 */       findPackage(name);
/* 163 */       return findClass(name);
/*     */     }
/*     */     catch (Exception ex) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 170 */     return super.loadClass(name, false);
/*     */   }
/*     */   
/*     */   private void findPackage(String name) throws ClassNotFoundException {
/* 174 */     int lastDot = name.lastIndexOf('.');
/* 175 */     if (lastDot != -1) {
/* 176 */       String packageName = name.substring(0, lastDot);
/* 177 */       if (getPackage(packageName) == null) {
/*     */         try {
/* 179 */           definePackageForFindClass(name, packageName);
/*     */         }
/*     */         catch (Exception ex) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void definePackageForFindClass(final String name, final String packageName)
/*     */   {
/*     */     try
/*     */     {
/* 196 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */       {
/*     */         public Object run() throws ClassNotFoundException {
/* 199 */           String path = name.replace('.', '/').concat(".class");
/* 200 */           for (URL url : LaunchedURLClassLoader.this.getURLs()) {
/*     */             try {
/* 202 */               if ((url.getContent() instanceof JarFile)) {
/* 203 */                 JarFile jarFile = (JarFile)url.getContent();
/*     */                 
/*     */ 
/* 206 */                 if ((jarFile.getJarEntryData(path) != null) && (jarFile.getManifest() != null))
/*     */                 {
/* 208 */                   LaunchedURLClassLoader.this.definePackage(packageName, jarFile.getManifest(), url);
/* 209 */                   return null;
/*     */                 }
/*     */               }
/*     */             }
/*     */             catch (IOException ex) {}
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 218 */           return null; } }, AccessController.getContext());
/*     */     }
/*     */     catch (PrivilegedActionException ex) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static LockProvider setupLockProvider()
/*     */   {
/*     */     try
/*     */     {
/* 229 */       ClassLoader.registerAsParallelCapable();
/* 230 */       return new Java7LockProvider(null);
/*     */     }
/*     */     catch (NoSuchMethodError ex) {}
/* 233 */     return new LockProvider(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class LockProvider
/*     */   {
/*     */     public Object getLock(LaunchedURLClassLoader classLoader, String className)
/*     */     {
/* 243 */       return classLoader;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Java7LockProvider extends LaunchedURLClassLoader.LockProvider
/*     */   {
/*     */     private Java7LockProvider()
/*     */     {
/* 251 */       super();
/*     */     }
/*     */     
/*     */     public Object getLock(LaunchedURLClassLoader classLoader, String className) {
/* 255 */       return classLoader.getClassLoadingLock(className);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\LaunchedURLClassLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */