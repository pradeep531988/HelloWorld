/*    */ package org.springframework.boot.loader;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MainMethodRunner
/*    */   implements Runnable
/*    */ {
/*    */   private final String mainClassName;
/*    */   private final String[] args;
/*    */   
/*    */   public MainMethodRunner(String mainClass, String[] args)
/*    */   {
/* 39 */     this.mainClassName = mainClass;
/* 40 */     this.args = (args == null ? null : (String[])args.clone());
/*    */   }
/*    */   
/*    */   public void run()
/*    */   {
/*    */     try {
/* 46 */       Class<?> mainClass = Thread.currentThread().getContextClassLoader().loadClass(this.mainClassName);
/*    */       
/* 48 */       Method mainMethod = mainClass.getDeclaredMethod("main", new Class[] { String[].class });
/* 49 */       if (mainMethod == null) {
/* 50 */         throw new IllegalStateException(this.mainClassName + " does not have a main method");
/*    */       }
/*    */       
/* 53 */       mainMethod.invoke(null, new Object[] { this.args });
/*    */     }
/*    */     catch (Exception ex) {
/* 56 */       ex.printStackTrace();
/* 57 */       System.exit(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\MainMethodRunner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */