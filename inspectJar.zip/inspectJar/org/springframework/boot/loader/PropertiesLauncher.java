/*     */ package org.springframework.boot.loader;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.Manifest;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.boot.loader.archive.Archive;
/*     */ import org.springframework.boot.loader.archive.Archive.Entry;
/*     */ import org.springframework.boot.loader.archive.Archive.EntryFilter;
/*     */ import org.springframework.boot.loader.archive.ExplodedArchive;
/*     */ import org.springframework.boot.loader.archive.FilteredArchive;
/*     */ import org.springframework.boot.loader.archive.JarFileArchive;
/*     */ import org.springframework.boot.loader.util.AsciiBytes;
/*     */ import org.springframework.boot.loader.util.SystemPropertyUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertiesLauncher
/*     */   extends Launcher
/*     */ {
/*  78 */   private final Logger logger = Logger.getLogger(Launcher.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String MAIN = "loader.main";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PATH = "loader.path";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String HOME = "loader.home";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String ARGS = "loader.args";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String CONFIG_NAME = "loader.config.name";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String CONFIG_LOCATION = "loader.config.location";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String SET_SYSTEM_PROPERTIES = "loader.system";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */   private static final List<String> DEFAULT_PATHS = Arrays.asList(new Object[0]);
/*     */   
/* 129 */   private static final Pattern WORD_SEPARATOR = Pattern.compile("\\W+");
/*     */   
/* 131 */   private static final URL[] EMPTY_URLS = new URL[0];
/*     */   
/*     */   private final File home;
/*     */   
/* 135 */   private List<String> paths = new ArrayList(DEFAULT_PATHS);
/*     */   
/* 137 */   private final Properties properties = new Properties();
/*     */   private Archive parent;
/*     */   
/*     */   public PropertiesLauncher()
/*     */   {
/* 142 */     if (!isDebug()) {
/* 143 */       this.logger.setLevel(Level.SEVERE);
/*     */     }
/*     */     try {
/* 146 */       this.home = getHomeDirectory();
/* 147 */       initializeProperties(this.home);
/* 148 */       initializePaths();
/* 149 */       this.parent = createArchive();
/*     */     }
/*     */     catch (Exception ex) {
/* 152 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isDebug() {
/* 157 */     String debug = System.getProperty("debug");
/* 158 */     if ((debug != null) && (!"false".equals(debug))) {
/* 159 */       return true;
/*     */     }
/* 161 */     debug = System.getProperty("DEBUG");
/* 162 */     if ((debug != null) && (!"false".equals(debug))) {
/* 163 */       return true;
/*     */     }
/* 165 */     debug = System.getenv("DEBUG");
/* 166 */     if ((debug != null) && (!"false".equals(debug))) {
/* 167 */       return true;
/*     */     }
/* 169 */     return false;
/*     */   }
/*     */   
/*     */   protected File getHomeDirectory() {
/* 173 */     return new File(SystemPropertyUtils.resolvePlaceholders(System.getProperty("loader.home", "${user.dir}")));
/*     */   }
/*     */   
/*     */   private void initializeProperties(File home) throws Exception, IOException
/*     */   {
/* 178 */     String config = "classpath:" + SystemPropertyUtils.resolvePlaceholders(SystemPropertyUtils.getProperty("loader.config.name", "application")) + ".properties";
/*     */     
/*     */ 
/* 181 */     config = SystemPropertyUtils.resolvePlaceholders(SystemPropertyUtils.getProperty("loader.config.location", config));
/*     */     
/* 183 */     InputStream resource = getResource(config);
/*     */     
/* 185 */     if (resource != null) {
/* 186 */       this.logger.info("Found: " + config);
/*     */       try {
/* 188 */         this.properties.load(resource);
/*     */       }
/*     */       finally {
/* 191 */         resource.close();
/*     */       }
/* 193 */       for (Object key : Collections.list(this.properties.propertyNames())) {
/* 194 */         String text = this.properties.getProperty((String)key);
/* 195 */         String value = SystemPropertyUtils.resolvePlaceholders(this.properties, text);
/*     */         
/* 197 */         if (value != null) {
/* 198 */           this.properties.put(key, value);
/*     */         }
/*     */       }
/* 201 */       if (SystemPropertyUtils.resolvePlaceholders("${loader.system:false}").equals("true"))
/*     */       {
/* 203 */         this.logger.info("Adding resolved properties to System properties");
/* 204 */         for (Object key : Collections.list(this.properties.propertyNames())) {
/* 205 */           String value = this.properties.getProperty((String)key);
/* 206 */           System.setProperty((String)key, value);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 211 */       this.logger.info("Not found: " + config);
/*     */     }
/*     */   }
/*     */   
/*     */   private InputStream getResource(String config) throws Exception
/*     */   {
/* 217 */     if (config.startsWith("classpath:")) {
/* 218 */       return getClasspathResource(config.substring("classpath:".length()));
/*     */     }
/* 220 */     config = stripFileUrlPrefix(config);
/* 221 */     if (isUrl(config)) {
/* 222 */       return getURLResource(config);
/*     */     }
/* 224 */     return getFileResource(config);
/*     */   }
/*     */   
/*     */   private String stripFileUrlPrefix(String config) {
/* 228 */     if (config.startsWith("file:")) {
/* 229 */       config = config.substring("file:".length());
/* 230 */       if (config.startsWith("//")) {
/* 231 */         config = config.substring(2);
/*     */       }
/*     */     }
/* 234 */     return config;
/*     */   }
/*     */   
/*     */   private boolean isUrl(String config) {
/* 238 */     return config.contains("://");
/*     */   }
/*     */   
/*     */   private InputStream getClasspathResource(String config) {
/* 242 */     while (config.startsWith("/")) {
/* 243 */       config = config.substring(1);
/*     */     }
/* 245 */     config = "/" + config;
/* 246 */     this.logger.fine("Trying classpath: " + config);
/* 247 */     return getClass().getResourceAsStream(config);
/*     */   }
/*     */   
/*     */   private InputStream getFileResource(String config) throws Exception {
/* 251 */     File file = new File(config);
/* 252 */     this.logger.fine("Trying file: " + config);
/* 253 */     if (file.canRead()) {
/* 254 */       return new FileInputStream(file);
/*     */     }
/* 256 */     return null;
/*     */   }
/*     */   
/*     */   private InputStream getURLResource(String config) throws Exception {
/* 260 */     URL url = new URL(config);
/* 261 */     if (exists(url)) {
/* 262 */       URLConnection con = url.openConnection();
/*     */       try {
/* 264 */         return con.getInputStream();
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 268 */         if ((con instanceof HttpURLConnection)) {
/* 269 */           ((HttpURLConnection)con).disconnect();
/*     */         }
/* 271 */         throw ex;
/*     */       }
/*     */     }
/* 274 */     return null;
/*     */   }
/*     */   
/*     */   private boolean exists(URL url) throws IOException
/*     */   {
/* 279 */     URLConnection connection = url.openConnection();
/*     */     try {
/* 281 */       connection.setUseCaches(connection.getClass().getSimpleName().startsWith("JNLP"));
/*     */       HttpURLConnection httpConnection;
/* 283 */       if ((connection instanceof HttpURLConnection)) {
/* 284 */         httpConnection = (HttpURLConnection)connection;
/* 285 */         httpConnection.setRequestMethod("HEAD");
/* 286 */         int responseCode = httpConnection.getResponseCode();
/* 287 */         boolean bool; if (responseCode == 200) {
/* 288 */           return true;
/*     */         }
/* 290 */         if (responseCode == 404) {
/* 291 */           return false;
/*     */         }
/*     */       }
/* 294 */       return connection.getContentLength() >= 0 ? 1 : 0;
/*     */     }
/*     */     finally {
/* 297 */       if ((connection instanceof HttpURLConnection)) {
/* 298 */         ((HttpURLConnection)connection).disconnect();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void initializePaths() throws IOException {
/* 304 */     String path = SystemPropertyUtils.getProperty("loader.path");
/* 305 */     if (path == null) {
/* 306 */       path = this.properties.getProperty("loader.path");
/*     */     }
/* 308 */     if (path != null) {
/* 309 */       this.paths = parsePathsProperty(SystemPropertyUtils.resolvePlaceholders(path));
/*     */     }
/* 311 */     this.logger.info("Nested archive paths: " + this.paths);
/*     */   }
/*     */   
/*     */   private List<String> parsePathsProperty(String commaSeparatedPaths) {
/* 315 */     List<String> paths = new ArrayList();
/* 316 */     for (String path : commaSeparatedPaths.split(",")) {
/* 317 */       path = cleanupPath(path);
/*     */       
/*     */ 
/* 320 */       if (!path.equals("")) {
/* 321 */         paths.add(path);
/*     */       }
/*     */     }
/* 324 */     if (paths.isEmpty()) {
/* 325 */       paths.add("lib");
/*     */     }
/* 327 */     return paths;
/*     */   }
/*     */   
/*     */   protected String[] getArgs(String... args) throws Exception {
/* 331 */     String loaderArgs = getProperty("loader.args");
/* 332 */     if (loaderArgs != null) {
/* 333 */       String[] defaultArgs = loaderArgs.split("\\s+");
/* 334 */       String[] additionalArgs = args;
/* 335 */       args = new String[defaultArgs.length + additionalArgs.length];
/* 336 */       System.arraycopy(defaultArgs, 0, args, 0, defaultArgs.length);
/* 337 */       System.arraycopy(additionalArgs, 0, args, defaultArgs.length, additionalArgs.length);
/*     */     }
/*     */     
/* 340 */     return args;
/*     */   }
/*     */   
/*     */   protected String getMainClass() throws Exception
/*     */   {
/* 345 */     String mainClass = getProperty("loader.main", "Start-Class");
/* 346 */     if (mainClass == null) {
/* 347 */       throw new IllegalStateException("No 'loader.main' or 'Start-Class' specified");
/*     */     }
/*     */     
/* 350 */     return mainClass;
/*     */   }
/*     */   
/*     */   protected ClassLoader createClassLoader(List<Archive> archives) throws Exception
/*     */   {
/* 355 */     ClassLoader loader = super.createClassLoader(archives);
/* 356 */     String customLoaderClassName = getProperty("loader.classLoader");
/* 357 */     if (customLoaderClassName != null) {
/* 358 */       loader = wrapWithCustomClassLoader(loader, customLoaderClassName);
/* 359 */       this.logger.info("Using custom class loader: " + customLoaderClassName);
/*     */     }
/* 361 */     return loader;
/*     */   }
/*     */   
/*     */ 
/*     */   private ClassLoader wrapWithCustomClassLoader(ClassLoader parent, String loaderClassName)
/*     */     throws Exception
/*     */   {
/* 368 */     Class<ClassLoader> loaderClass = Class.forName(loaderClassName, true, parent);
/*     */     
/*     */     try
/*     */     {
/* 372 */       return (ClassLoader)loaderClass.getConstructor(new Class[] { ClassLoader.class }).newInstance(new Object[] { parent });
/*     */ 
/*     */     }
/*     */     catch (NoSuchMethodException ex)
/*     */     {
/*     */       try
/*     */       {
/* 379 */         return (ClassLoader)loaderClass.getConstructor(new Class[] { URL[].class, ClassLoader.class }).newInstance(new Object[] { new URL[0], parent });
/*     */       }
/*     */       catch (NoSuchMethodException ex) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 386 */     return (ClassLoader)loaderClass.newInstance();
/*     */   }
/*     */   
/*     */   private String getProperty(String propertyKey) throws Exception {
/* 390 */     return getProperty(propertyKey, null);
/*     */   }
/*     */   
/*     */   private String getProperty(String propertyKey, String manifestKey) throws Exception {
/* 394 */     if (manifestKey == null) {
/* 395 */       manifestKey = propertyKey.replace(".", "-");
/* 396 */       manifestKey = toCamelCase(manifestKey);
/*     */     }
/*     */     
/* 399 */     String property = SystemPropertyUtils.getProperty(propertyKey);
/* 400 */     if (property != null) {
/* 401 */       String value = SystemPropertyUtils.resolvePlaceholders(property);
/* 402 */       this.logger.fine("Property '" + propertyKey + "' from environment: " + value);
/* 403 */       return value;
/*     */     }
/*     */     
/* 406 */     if (this.properties.containsKey(propertyKey)) {
/* 407 */       String value = SystemPropertyUtils.resolvePlaceholders(this.properties.getProperty(propertyKey));
/*     */       
/* 409 */       this.logger.fine("Property '" + propertyKey + "' from properties: " + value);
/* 410 */       return value;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 415 */       Manifest manifest = new ExplodedArchive(this.home, false).getManifest();
/* 416 */       if (manifest != null) {
/* 417 */         String value = manifest.getMainAttributes().getValue(manifestKey);
/* 418 */         this.logger.fine("Property '" + manifestKey + "' from home directory manifest: " + value);
/*     */         
/* 420 */         return value;
/*     */       }
/*     */     }
/*     */     catch (IllegalStateException ex) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 428 */     Manifest manifest = createArchive().getManifest();
/* 429 */     if (manifest != null) {
/* 430 */       String value = manifest.getMainAttributes().getValue(manifestKey);
/* 431 */       if (value != null) {
/* 432 */         this.logger.fine("Property '" + manifestKey + "' from archive manifest: " + value);
/*     */         
/* 434 */         return value;
/*     */       }
/*     */     }
/* 437 */     return null;
/*     */   }
/*     */   
/*     */   protected List<Archive> getClassPathArchives() throws Exception
/*     */   {
/* 442 */     List<Archive> lib = new ArrayList();
/* 443 */     for (String path : this.paths) {
/* 444 */       for (Archive archive : getClassPathArchives(path)) {
/* 445 */         List<Archive> nested = new ArrayList(archive.getNestedArchives(new ArchiveEntryFilter(null)));
/*     */         
/* 447 */         nested.add(0, archive);
/* 448 */         lib.addAll(nested);
/*     */       }
/*     */     }
/* 451 */     addParentClassLoaderEntries(lib);
/*     */     
/* 453 */     Collections.reverse(lib);
/* 454 */     return lib;
/*     */   }
/*     */   
/*     */   private List<Archive> getClassPathArchives(String path) throws Exception {
/* 458 */     String root = cleanupPath(stripFileUrlPrefix(path));
/* 459 */     List<Archive> lib = new ArrayList();
/* 460 */     File file = new File(root);
/* 461 */     if (!isAbsolutePath(root)) {
/* 462 */       file = new File(this.home, root);
/*     */     }
/* 464 */     if (file.isDirectory()) {
/* 465 */       this.logger.info("Adding classpath entries from " + file);
/* 466 */       Archive archive = new ExplodedArchive(file, false);
/* 467 */       lib.add(archive);
/*     */     }
/* 469 */     Archive archive = getArchive(file);
/* 470 */     if (archive != null) {
/* 471 */       this.logger.info("Adding classpath entries from archive " + archive.getUrl() + root);
/*     */       
/* 473 */       lib.add(archive);
/*     */     }
/* 475 */     Archive nested = getNestedArchive(root);
/* 476 */     if (nested != null) {
/* 477 */       this.logger.info("Adding classpath entries from nested " + nested.getUrl() + root);
/*     */       
/* 479 */       lib.add(nested);
/*     */     }
/* 481 */     return lib;
/*     */   }
/*     */   
/*     */   private boolean isAbsolutePath(String root)
/*     */   {
/* 486 */     return (root.contains(":")) || (root.startsWith("/"));
/*     */   }
/*     */   
/*     */   private Archive getArchive(File file) throws IOException {
/* 490 */     String name = file.getName().toLowerCase();
/* 491 */     if ((name.endsWith(".jar")) || (name.endsWith(".zip"))) {
/* 492 */       return new JarFileArchive(file);
/*     */     }
/* 494 */     return null;
/*     */   }
/*     */   
/*     */   private Archive getNestedArchive(String root) throws Exception {
/* 498 */     if ((root.startsWith("/")) || (this.parent.getUrl().equals(this.home.toURI().toURL())))
/*     */     {
/*     */ 
/* 501 */       return null;
/*     */     }
/* 503 */     Archive.EntryFilter filter = new PrefixMatchingArchiveFilter(root, null);
/* 504 */     if (this.parent.getNestedArchives(filter).isEmpty()) {
/* 505 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 509 */     return new FilteredArchive(this.parent, filter);
/*     */   }
/*     */   
/*     */   private void addParentClassLoaderEntries(List<Archive> lib) throws IOException, URISyntaxException
/*     */   {
/* 514 */     ClassLoader parentClassLoader = getClass().getClassLoader();
/* 515 */     List<Archive> urls = new ArrayList();
/* 516 */     for (URL url : getURLs(parentClassLoader)) {
/* 517 */       if ((url.toString().endsWith(".jar")) || (url.toString().endsWith(".zip"))) {
/* 518 */         urls.add(new JarFileArchive(new File(url.toURI())));
/*     */       }
/* 520 */       else if (url.toString().endsWith("/*")) {
/* 521 */         String name = url.getFile();
/* 522 */         File dir = new File(name.substring(0, name.length() - 1));
/* 523 */         if (dir.exists()) {
/* 524 */           urls.add(new ExplodedArchive(new File(name.substring(0, name.length() - 1)), false));
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 529 */         String filename = URLDecoder.decode(url.getFile(), "UTF-8");
/* 530 */         urls.add(new ExplodedArchive(new File(filename)));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 536 */     addNestedArchivesFromParent(urls);
/* 537 */     for (Archive archive : urls)
/*     */     {
/* 539 */       if (findArchive(lib, archive) < 0) {
/* 540 */         lib.add(archive);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addNestedArchivesFromParent(List<Archive> urls) {
/* 546 */     int index = findArchive(urls, this.parent);
/* 547 */     if (index >= 0) {
/*     */       try {
/* 549 */         Archive nested = getNestedArchive("lib/");
/* 550 */         if (nested != null) {
/* 551 */           List<Archive> extra = new ArrayList(nested.getNestedArchives(new ArchiveEntryFilter(null)));
/*     */           
/* 553 */           urls.addAll(index + 1, extra);
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int findArchive(List<Archive> urls, Archive archive)
/*     */   {
/* 565 */     if (archive == null) {
/* 566 */       return -1;
/*     */     }
/* 568 */     int i = 0;
/* 569 */     for (Archive url : urls) {
/* 570 */       if (url.toString().equals(archive.toString())) {
/* 571 */         return i;
/*     */       }
/* 573 */       i++;
/*     */     }
/* 575 */     return -1;
/*     */   }
/*     */   
/*     */   private URL[] getURLs(ClassLoader classLoader) {
/* 579 */     if ((classLoader instanceof URLClassLoader)) {
/* 580 */       return ((URLClassLoader)classLoader).getURLs();
/*     */     }
/* 582 */     return EMPTY_URLS;
/*     */   }
/*     */   
/*     */   private String cleanupPath(String path) {
/* 586 */     path = path.trim();
/*     */     
/* 588 */     if (path.startsWith("./")) {
/* 589 */       path = path.substring(2);
/*     */     }
/* 591 */     if ((path.toLowerCase().endsWith(".jar")) || (path.toLowerCase().endsWith(".zip"))) {
/* 592 */       return path;
/*     */     }
/* 594 */     if (path.endsWith("/*")) {
/* 595 */       path = path.substring(0, path.length() - 1);
/*     */ 
/*     */ 
/*     */     }
/* 599 */     else if ((!path.endsWith("/")) && (!path.equals("."))) {
/* 600 */       path = path + "/";
/*     */     }
/*     */     
/* 603 */     return path;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 607 */     PropertiesLauncher launcher = new PropertiesLauncher();
/* 608 */     args = launcher.getArgs(args);
/* 609 */     launcher.launch(args);
/*     */   }
/*     */   
/*     */   public static String toCamelCase(CharSequence string) {
/* 613 */     if (string == null) {
/* 614 */       return null;
/*     */     }
/* 616 */     StringBuilder builder = new StringBuilder();
/* 617 */     Matcher matcher = WORD_SEPARATOR.matcher(string);
/* 618 */     int pos = 0;
/* 619 */     while (matcher.find()) {
/* 620 */       builder.append(capitalize(string.subSequence(pos, matcher.end()).toString()));
/* 621 */       pos = matcher.end();
/*     */     }
/* 623 */     builder.append(capitalize(string.subSequence(pos, string.length()).toString()));
/* 624 */     return builder.toString();
/*     */   }
/*     */   
/*     */   private static Object capitalize(String str) {
/* 628 */     StringBuilder sb = new StringBuilder(str.length());
/* 629 */     sb.append(Character.toUpperCase(str.charAt(0)));
/* 630 */     sb.append(str.substring(1));
/* 631 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class ArchiveEntryFilter
/*     */     implements Archive.EntryFilter
/*     */   {
/* 640 */     private static final AsciiBytes DOT_JAR = new AsciiBytes(".jar");
/*     */     
/* 642 */     private static final AsciiBytes DOT_ZIP = new AsciiBytes(".zip");
/*     */     
/*     */     public boolean matches(Archive.Entry entry)
/*     */     {
/* 646 */       return (entry.getName().endsWith(DOT_JAR)) || (entry.getName().endsWith(DOT_ZIP));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class PrefixMatchingArchiveFilter
/*     */     implements Archive.EntryFilter
/*     */   {
/*     */     private final AsciiBytes prefix;
/*     */     
/*     */ 
/* 658 */     private final PropertiesLauncher.ArchiveEntryFilter filter = new PropertiesLauncher.ArchiveEntryFilter(null);
/*     */     
/*     */     private PrefixMatchingArchiveFilter(String prefix) {
/* 661 */       this.prefix = new AsciiBytes(prefix);
/*     */     }
/*     */     
/*     */     public boolean matches(Archive.Entry entry)
/*     */     {
/* 666 */       return (entry.getName().startsWith(this.prefix)) && (this.filter.matches(entry));
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\PropertiesLauncher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */