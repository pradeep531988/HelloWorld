/*    */ package org.springframework.boot.loader;
/*    */ 
/*    */ import org.springframework.boot.loader.archive.Archive;
/*    */ import org.springframework.boot.loader.archive.Archive.Entry;
/*    */ import org.springframework.boot.loader.util.AsciiBytes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WarLauncher
/*    */   extends ExecutableArchiveLauncher
/*    */ {
/* 32 */   private static final AsciiBytes WEB_INF = new AsciiBytes("WEB-INF/");
/*    */   
/* 34 */   private static final AsciiBytes WEB_INF_CLASSES = WEB_INF.append("classes/");
/*    */   
/* 36 */   private static final AsciiBytes WEB_INF_LIB = WEB_INF.append("lib/");
/*    */   
/* 38 */   private static final AsciiBytes WEB_INF_LIB_PROVIDED = WEB_INF.append("lib-provided/");
/*    */   
/*    */ 
/*    */   public WarLauncher() {}
/*    */   
/*    */ 
/*    */   WarLauncher(Archive archive)
/*    */   {
/* 46 */     super(archive);
/*    */   }
/*    */   
/*    */   public boolean isNestedArchive(Archive.Entry entry)
/*    */   {
/* 51 */     if (entry.isDirectory()) {
/* 52 */       return entry.getName().equals(WEB_INF_CLASSES);
/*    */     }
/*    */     
/* 55 */     return (entry.getName().startsWith(WEB_INF_LIB)) || (entry.getName().startsWith(WEB_INF_LIB_PROVIDED));
/*    */   }
/*    */   
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 61 */     new WarLauncher().launch(args);
/*    */   }
/*    */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\WarLauncher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */