/*    */ package org.springframework.boot.loader.archive;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.jar.Attributes;
/*    */ import java.util.jar.Manifest;
/*    */ import org.springframework.boot.loader.util.AsciiBytes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Archive
/*    */ {
/*    */   public abstract URL getUrl()
/*    */     throws MalformedURLException;
/*    */   
/*    */   public String getMainClass()
/*    */     throws Exception
/*    */   {
/* 51 */     Manifest manifest = getManifest();
/* 52 */     String mainClass = null;
/* 53 */     if (manifest != null) {
/* 54 */       mainClass = manifest.getMainAttributes().getValue("Start-Class");
/*    */     }
/* 56 */     if (mainClass == null) {
/* 57 */       throw new IllegalStateException("No 'Start-Class' manifest entry specified in " + this);
/*    */     }
/*    */     
/* 60 */     return mainClass;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/*    */     try {
/* 66 */       return getUrl().toString();
/*    */     }
/*    */     catch (Exception ex) {}
/* 69 */     return "archive";
/*    */   }
/*    */   
/*    */   public abstract Manifest getManifest()
/*    */     throws IOException;
/*    */   
/*    */   public abstract Collection<Entry> getEntries();
/*    */   
/*    */   public abstract List<Archive> getNestedArchives(EntryFilter paramEntryFilter)
/*    */     throws IOException;
/*    */   
/*    */   public abstract Archive getFilteredArchive(EntryRenameFilter paramEntryRenameFilter)
/*    */     throws IOException;
/*    */   
/*    */   public static abstract interface EntryRenameFilter
/*    */   {
/*    */     public abstract AsciiBytes apply(AsciiBytes paramAsciiBytes, Archive.Entry paramEntry);
/*    */   }
/*    */   
/*    */   public static abstract interface EntryFilter
/*    */   {
/*    */     public abstract boolean matches(Archive.Entry paramEntry);
/*    */   }
/*    */   
/*    */   public static abstract interface Entry
/*    */   {
/*    */     public abstract boolean isDirectory();
/*    */     
/*    */     public abstract AsciiBytes getName();
/*    */   }
/*    */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\archive\Archive.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */