/*     */ package org.springframework.boot.loader.archive;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.jar.Manifest;
/*     */ import org.springframework.boot.loader.util.AsciiBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExplodedArchive
/*     */   extends Archive
/*     */ {
/*  47 */   private static final Set<String> SKIPPED_NAMES = new HashSet(Arrays.asList(new String[] { ".", ".." }));
/*     */   
/*     */ 
/*  50 */   private static final AsciiBytes MANIFEST_ENTRY_NAME = new AsciiBytes("META-INF/MANIFEST.MF");
/*     */   
/*     */ 
/*     */   private final File root;
/*     */   
/*  55 */   private Map<AsciiBytes, Archive.Entry> entries = new LinkedHashMap();
/*     */   
/*     */   private Manifest manifest;
/*     */   
/*  59 */   private boolean filtered = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExplodedArchive(File root)
/*     */   {
/*  66 */     this(root, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExplodedArchive(File root, boolean recursive)
/*     */   {
/*  77 */     if ((!root.exists()) || (!root.isDirectory())) {
/*  78 */       throw new IllegalArgumentException("Invalid source folder " + root);
/*     */     }
/*  80 */     this.root = root;
/*  81 */     buildEntries(root, recursive);
/*  82 */     this.entries = Collections.unmodifiableMap(this.entries);
/*     */   }
/*     */   
/*     */   private ExplodedArchive(File root, Map<AsciiBytes, Archive.Entry> entries) {
/*  86 */     this.root = root;
/*     */     
/*  88 */     this.filtered = true;
/*  89 */     this.entries = Collections.unmodifiableMap(entries);
/*     */   }
/*     */   
/*     */   private void buildEntries(File file, boolean recursive) {
/*  93 */     if (!file.equals(this.root)) {
/*  94 */       String name = file.toURI().getPath().substring(this.root.toURI().getPath().length());
/*     */       
/*  96 */       FileEntry entry = new FileEntry(new AsciiBytes(name), file);
/*  97 */       this.entries.put(entry.getName(), entry);
/*     */     }
/*  99 */     if (file.isDirectory()) {
/* 100 */       File[] files = file.listFiles();
/* 101 */       if (files == null) {
/* 102 */         return;
/*     */       }
/* 104 */       for (File child : files) {
/* 105 */         if ((!SKIPPED_NAMES.contains(child.getName())) && (
/* 106 */           (file.equals(this.root)) || (recursive) || (file.getName().equals("META-INF"))))
/*     */         {
/* 108 */           buildEntries(child, recursive);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public URL getUrl()
/*     */     throws MalformedURLException
/*     */   {
/* 117 */     FilteredURLStreamHandler handler = this.filtered ? new FilteredURLStreamHandler() : null;
/*     */     
/* 119 */     return new URL("file", "", -1, this.root.toURI().getPath(), handler);
/*     */   }
/*     */   
/*     */   public Manifest getManifest() throws IOException
/*     */   {
/* 124 */     if ((this.manifest == null) && (this.entries.containsKey(MANIFEST_ENTRY_NAME))) {
/* 125 */       FileEntry entry = (FileEntry)this.entries.get(MANIFEST_ENTRY_NAME);
/* 126 */       FileInputStream inputStream = new FileInputStream(entry.getFile());
/*     */       try {
/* 128 */         this.manifest = new Manifest(inputStream);
/*     */       }
/*     */       finally {
/* 131 */         inputStream.close();
/*     */       }
/*     */     }
/* 134 */     return this.manifest;
/*     */   }
/*     */   
/*     */   public List<Archive> getNestedArchives(Archive.EntryFilter filter) throws IOException
/*     */   {
/* 139 */     List<Archive> nestedArchives = new ArrayList();
/* 140 */     for (Archive.Entry entry : getEntries()) {
/* 141 */       if (filter.matches(entry)) {
/* 142 */         nestedArchives.add(getNestedArchive(entry));
/*     */       }
/*     */     }
/* 145 */     return Collections.unmodifiableList(nestedArchives);
/*     */   }
/*     */   
/*     */   public Collection<Archive.Entry> getEntries()
/*     */   {
/* 150 */     return Collections.unmodifiableCollection(this.entries.values());
/*     */   }
/*     */   
/*     */   protected Archive getNestedArchive(Archive.Entry entry) throws IOException {
/* 154 */     File file = ((FileEntry)entry).getFile();
/* 155 */     return file.isDirectory() ? new ExplodedArchive(file) : new JarFileArchive(file);
/*     */   }
/*     */   
/*     */   public Archive getFilteredArchive(Archive.EntryRenameFilter filter) throws IOException
/*     */   {
/* 160 */     Map<AsciiBytes, Archive.Entry> filteredEntries = new LinkedHashMap();
/* 161 */     for (Map.Entry<AsciiBytes, Archive.Entry> entry : this.entries.entrySet()) {
/* 162 */       AsciiBytes filteredName = filter.apply((AsciiBytes)entry.getKey(), (Archive.Entry)entry.getValue());
/* 163 */       if (filteredName != null) {
/* 164 */         filteredEntries.put(filteredName, new FileEntry(filteredName, ((FileEntry)entry.getValue()).getFile()));
/*     */       }
/*     */     }
/*     */     
/* 168 */     return new ExplodedArchive(this.root, filteredEntries);
/*     */   }
/*     */   
/*     */   private class FileEntry implements Archive.Entry
/*     */   {
/*     */     private final AsciiBytes name;
/*     */     private final File file;
/*     */     
/*     */     public FileEntry(AsciiBytes name, File file)
/*     */     {
/* 178 */       this.name = name;
/* 179 */       this.file = file;
/*     */     }
/*     */     
/*     */     public File getFile() {
/* 183 */       return this.file;
/*     */     }
/*     */     
/*     */     public boolean isDirectory()
/*     */     {
/* 188 */       return this.file.isDirectory();
/*     */     }
/*     */     
/*     */     public AsciiBytes getName()
/*     */     {
/* 193 */       return this.name;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class FilteredURLStreamHandler
/*     */     extends URLStreamHandler
/*     */   {
/*     */     public FilteredURLStreamHandler() {}
/*     */     
/*     */ 
/*     */     protected URLConnection openConnection(URL url)
/*     */       throws IOException
/*     */     {
/* 207 */       String name = url.getPath().substring(ExplodedArchive.this.root.toURI().getPath().length());
/*     */       
/* 209 */       if (ExplodedArchive.this.entries.containsKey(new AsciiBytes(name))) {
/* 210 */         return new URL(url.toString()).openConnection();
/*     */       }
/* 212 */       return new ExplodedArchive.FileNotFoundURLConnection(url, name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class FileNotFoundURLConnection
/*     */     extends URLConnection
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     public FileNotFoundURLConnection(URL url, String name)
/*     */     {
/* 224 */       super();
/* 225 */       this.name = name;
/*     */     }
/*     */     
/*     */     public void connect() throws IOException
/*     */     {
/* 230 */       throw new FileNotFoundException(this.name);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\archive\ExplodedArchive.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */