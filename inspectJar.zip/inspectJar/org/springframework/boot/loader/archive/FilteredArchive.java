/*    */ package org.springframework.boot.loader.archive;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.jar.Manifest;
/*    */ import org.springframework.boot.loader.util.AsciiBytes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilteredArchive
/*    */   extends Archive
/*    */ {
/*    */   private final Archive parent;
/*    */   private final Archive.EntryFilter filter;
/*    */   
/*    */   public FilteredArchive(Archive parent, Archive.EntryFilter filter)
/*    */   {
/* 42 */     this.parent = parent;
/* 43 */     this.filter = filter;
/*    */   }
/*    */   
/*    */   public URL getUrl() throws MalformedURLException
/*    */   {
/* 48 */     return this.parent.getUrl();
/*    */   }
/*    */   
/*    */   public String getMainClass() throws Exception
/*    */   {
/* 53 */     return this.parent.getMainClass();
/*    */   }
/*    */   
/*    */   public Manifest getManifest() throws IOException
/*    */   {
/* 58 */     return this.parent.getManifest();
/*    */   }
/*    */   
/*    */   public Collection<Archive.Entry> getEntries()
/*    */   {
/* 63 */     List<Archive.Entry> nested = new ArrayList();
/* 64 */     for (Archive.Entry entry : this.parent.getEntries()) {
/* 65 */       if (this.filter.matches(entry)) {
/* 66 */         nested.add(entry);
/*    */       }
/*    */     }
/* 69 */     return Collections.unmodifiableList(nested);
/*    */   }
/*    */   
/*    */   public List<Archive> getNestedArchives(final Archive.EntryFilter filter) throws IOException
/*    */   {
/* 74 */     this.parent.getNestedArchives(new Archive.EntryFilter()
/*    */     {
/*    */       public boolean matches(Archive.Entry entry) {
/* 77 */         return (FilteredArchive.this.filter.matches(entry)) && (filter.matches(entry));
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   public Archive getFilteredArchive(final Archive.EntryRenameFilter filter)
/*    */     throws IOException
/*    */   {
/* 85 */     this.parent.getFilteredArchive(new Archive.EntryRenameFilter()
/*    */     {
/*    */       public AsciiBytes apply(AsciiBytes entryName, Archive.Entry entry) {
/* 88 */         return FilteredArchive.this.filter.matches(entry) ? filter.apply(entryName, entry) : null;
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\archive\FilteredArchive.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */