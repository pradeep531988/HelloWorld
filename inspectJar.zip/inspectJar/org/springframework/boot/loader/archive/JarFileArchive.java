/*     */ package org.springframework.boot.loader.archive;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.jar.Manifest;
/*     */ import org.springframework.boot.loader.data.RandomAccessData;
/*     */ import org.springframework.boot.loader.data.RandomAccessData.ResourceAccess;
/*     */ import org.springframework.boot.loader.jar.JarEntryData;
/*     */ import org.springframework.boot.loader.jar.JarEntryFilter;
/*     */ import org.springframework.boot.loader.jar.JarFile;
/*     */ import org.springframework.boot.loader.util.AsciiBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarFileArchive
/*     */   extends Archive
/*     */ {
/*  46 */   private static final AsciiBytes UNPACK_MARKER = new AsciiBytes("UNPACK:");
/*     */   
/*     */   private static final int BUFFER_SIZE = 32768;
/*     */   
/*     */   private final JarFile jarFile;
/*     */   private final List<Archive.Entry> entries;
/*     */   private URL url;
/*     */   
/*     */   public JarFileArchive(File file)
/*     */     throws IOException
/*     */   {
/*  57 */     this(file, null);
/*     */   }
/*     */   
/*     */   public JarFileArchive(File file, URL url) throws IOException {
/*  61 */     this(new JarFile(file));
/*  62 */     this.url = url;
/*     */   }
/*     */   
/*     */   public JarFileArchive(JarFile jarFile) {
/*  66 */     this.jarFile = jarFile;
/*  67 */     ArrayList<Archive.Entry> jarFileEntries = new ArrayList();
/*  68 */     for (JarEntryData data : jarFile) {
/*  69 */       jarFileEntries.add(new JarFileEntry(data));
/*     */     }
/*  71 */     this.entries = Collections.unmodifiableList(jarFileEntries);
/*     */   }
/*     */   
/*     */   public URL getUrl() throws MalformedURLException
/*     */   {
/*  76 */     if (this.url != null) {
/*  77 */       return this.url;
/*     */     }
/*  79 */     return this.jarFile.getUrl();
/*     */   }
/*     */   
/*     */   public Manifest getManifest() throws IOException
/*     */   {
/*  84 */     return this.jarFile.getManifest();
/*     */   }
/*     */   
/*     */   public List<Archive> getNestedArchives(Archive.EntryFilter filter) throws IOException
/*     */   {
/*  89 */     List<Archive> nestedArchives = new ArrayList();
/*  90 */     for (Archive.Entry entry : getEntries()) {
/*  91 */       if (filter.matches(entry)) {
/*  92 */         nestedArchives.add(getNestedArchive(entry));
/*     */       }
/*     */     }
/*  95 */     return Collections.unmodifiableList(nestedArchives);
/*     */   }
/*     */   
/*     */   public Collection<Archive.Entry> getEntries()
/*     */   {
/* 100 */     return Collections.unmodifiableCollection(this.entries);
/*     */   }
/*     */   
/*     */   protected Archive getNestedArchive(Archive.Entry entry) throws IOException {
/* 104 */     JarEntryData data = ((JarFileEntry)entry).getJarEntryData();
/* 105 */     if (data.getComment().startsWith(UNPACK_MARKER)) {
/* 106 */       return getUnpackedNestedArchive(data);
/*     */     }
/* 108 */     JarFile jarFile = this.jarFile.getNestedJarFile(data);
/* 109 */     return new JarFileArchive(jarFile);
/*     */   }
/*     */   
/*     */   private Archive getUnpackedNestedArchive(JarEntryData data) throws IOException {
/* 113 */     AsciiBytes hash = data.getComment().substring(UNPACK_MARKER.length());
/* 114 */     String name = data.getName().toString();
/* 115 */     if (name.lastIndexOf("/") != -1) {
/* 116 */       name = name.substring(name.lastIndexOf("/") + 1);
/*     */     }
/* 118 */     File file = new File(getTempUnpackFolder(), hash.toString() + "-" + name);
/* 119 */     if ((!file.exists()) || (file.length() != data.getSize())) {
/* 120 */       unpack(data, file);
/*     */     }
/* 122 */     return new JarFileArchive(file, file.toURI().toURL());
/*     */   }
/*     */   
/*     */   private File getTempUnpackFolder() {
/* 126 */     File tempFolder = new File(System.getProperty("java.io.tmpdir"));
/* 127 */     File unpackFolder = new File(tempFolder, "spring-boot-libs");
/* 128 */     unpackFolder.mkdirs();
/* 129 */     return unpackFolder;
/*     */   }
/*     */   
/*     */   private void unpack(JarEntryData data, File file) throws IOException {
/* 133 */     InputStream inputStream = data.getData().getInputStream(RandomAccessData.ResourceAccess.ONCE);
/*     */     try {
/* 135 */       OutputStream outputStream = new FileOutputStream(file);
/*     */       try {
/* 137 */         byte[] buffer = new byte[32768];
/* 138 */         int bytesRead = -1;
/* 139 */         while ((bytesRead = inputStream.read(buffer)) != -1) {
/* 140 */           outputStream.write(buffer, 0, bytesRead);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       finally {}
/*     */     }
/*     */     finally
/*     */     {
/* 149 */       inputStream.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public Archive getFilteredArchive(final Archive.EntryRenameFilter filter) throws IOException
/*     */   {
/* 155 */     JarFile filteredJar = this.jarFile.getFilteredJarFile(new JarEntryFilter[] { new JarEntryFilter()
/*     */     {
/*     */       public AsciiBytes apply(AsciiBytes name, JarEntryData entryData) {
/* 158 */         return filter.apply(name, new JarFileArchive.JarFileEntry(entryData));
/*     */       }
/* 160 */     } });
/* 161 */     return new JarFileArchive(filteredJar);
/*     */   }
/*     */   
/*     */ 
/*     */   private static class JarFileEntry
/*     */     implements Archive.Entry
/*     */   {
/*     */     private final JarEntryData entryData;
/*     */     
/*     */     public JarFileEntry(JarEntryData entryData)
/*     */     {
/* 172 */       this.entryData = entryData;
/*     */     }
/*     */     
/*     */     public JarEntryData getJarEntryData() {
/* 176 */       return this.entryData;
/*     */     }
/*     */     
/*     */     public boolean isDirectory()
/*     */     {
/* 181 */       return this.entryData.isDirectory();
/*     */     }
/*     */     
/*     */     public AsciiBytes getName()
/*     */     {
/* 186 */       return this.entryData.getName();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\archive\JarFileArchive.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */