/*     */ package org.springframework.boot.loader.data;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.Semaphore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RandomAccessDataFile
/*     */   implements RandomAccessData
/*     */ {
/*     */   private static final int DEFAULT_CONCURRENT_READS = 4;
/*     */   private final File file;
/*     */   private final FilePool filePool;
/*     */   private final long offset;
/*     */   private final long length;
/*     */   
/*     */   public RandomAccessDataFile(File file)
/*     */   {
/*  51 */     this(file, 4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RandomAccessDataFile(File file, int concurrentReads)
/*     */   {
/*  63 */     if (file == null) {
/*  64 */       throw new IllegalArgumentException("File must not be null");
/*     */     }
/*  66 */     if (!file.exists()) {
/*  67 */       throw new IllegalArgumentException("File must exist");
/*     */     }
/*  69 */     this.file = file;
/*  70 */     this.filePool = new FilePool(concurrentReads);
/*  71 */     this.offset = 0L;
/*  72 */     this.length = file.length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RandomAccessDataFile(File file, FilePool pool, long offset, long length)
/*     */   {
/*  82 */     this.file = file;
/*  83 */     this.filePool = pool;
/*  84 */     this.offset = offset;
/*  85 */     this.length = length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public File getFile()
/*     */   {
/*  93 */     return this.file;
/*     */   }
/*     */   
/*     */   public InputStream getInputStream(RandomAccessData.ResourceAccess access) throws IOException
/*     */   {
/*  98 */     return new DataInputStream(access);
/*     */   }
/*     */   
/*     */   public RandomAccessData getSubsection(long offset, long length)
/*     */   {
/* 103 */     if ((offset < 0L) || (length < 0L) || (offset + length > this.length)) {
/* 104 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 106 */     return new RandomAccessDataFile(this.file, this.filePool, this.offset + offset, length);
/*     */   }
/*     */   
/*     */ 
/*     */   public long getSize()
/*     */   {
/* 112 */     return this.length;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 116 */     this.filePool.close();
/*     */   }
/*     */   
/*     */ 
/*     */   private class DataInputStream
/*     */     extends InputStream
/*     */   {
/*     */     private RandomAccessFile file;
/*     */     
/*     */     private int position;
/*     */     
/*     */     public DataInputStream(RandomAccessData.ResourceAccess access)
/*     */       throws IOException
/*     */     {
/* 130 */       if (access == RandomAccessData.ResourceAccess.ONCE) {
/* 131 */         this.file = new RandomAccessFile(RandomAccessDataFile.this.file, "r");
/* 132 */         this.file.seek(RandomAccessDataFile.this.offset);
/*     */       }
/*     */     }
/*     */     
/*     */     public int read() throws IOException
/*     */     {
/* 138 */       return doRead(null, 0, 1);
/*     */     }
/*     */     
/*     */     public int read(byte[] b) throws IOException
/*     */     {
/* 143 */       return read(b, 0, b == null ? 0 : b.length);
/*     */     }
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException
/*     */     {
/* 148 */       if (b == null) {
/* 149 */         throw new NullPointerException("Bytes must not be null");
/*     */       }
/* 151 */       return doRead(b, off, len);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int doRead(byte[] b, int off, int len)
/*     */       throws IOException
/*     */     {
/* 164 */       if (len == 0) {
/* 165 */         return 0;
/*     */       }
/* 167 */       int cappedLen = cap(len);
/* 168 */       if (cappedLen <= 0) {
/* 169 */         return -1;
/*     */       }
/* 171 */       RandomAccessFile file = this.file;
/* 172 */       if (file == null) {
/* 173 */         file = RandomAccessDataFile.this.filePool.acquire();
/* 174 */         file.seek(RandomAccessDataFile.this.offset + this.position);
/*     */       }
/*     */       try { int rtn;
/* 177 */         if (b == null) {
/* 178 */           rtn = file.read();
/* 179 */           moveOn(rtn == -1 ? 0 : 1);
/* 180 */           return rtn;
/*     */         }
/*     */         
/* 183 */         return (int)moveOn(file.read(b, off, cappedLen));
/*     */       }
/*     */       finally
/*     */       {
/* 187 */         if (this.file == null) {
/* 188 */           RandomAccessDataFile.this.filePool.release(file);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public long skip(long n) throws IOException
/*     */     {
/* 195 */       return n <= 0L ? 0L : moveOn(cap(n));
/*     */     }
/*     */     
/*     */     public void close() throws IOException
/*     */     {
/* 200 */       if (this.file != null) {
/* 201 */         this.file.close();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private int cap(long n)
/*     */     {
/* 212 */       return (int)Math.min(RandomAccessDataFile.this.length - this.position, n);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private long moveOn(int amount)
/*     */     {
/* 221 */       this.position += amount;
/* 222 */       return amount;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class FilePool
/*     */   {
/*     */     private final int size;
/*     */     
/*     */ 
/*     */     private final Semaphore available;
/*     */     
/*     */     private final Queue<RandomAccessFile> files;
/*     */     
/*     */ 
/*     */     public FilePool(int size)
/*     */     {
/* 240 */       this.size = size;
/* 241 */       this.available = new Semaphore(size);
/* 242 */       this.files = new ConcurrentLinkedQueue();
/*     */     }
/*     */     
/*     */     public RandomAccessFile acquire() throws IOException
/*     */     {
/*     */       try {
/* 248 */         this.available.acquire();
/* 249 */         RandomAccessFile file = (RandomAccessFile)this.files.poll();
/* 250 */         return file == null ? new RandomAccessFile(RandomAccessDataFile.this.file, "r") : file;
/*     */       }
/*     */       catch (InterruptedException ex)
/*     */       {
/* 254 */         throw new IOException(ex);
/*     */       }
/*     */     }
/*     */     
/*     */     public void release(RandomAccessFile file) {
/* 259 */       this.files.add(file);
/* 260 */       this.available.release();
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/*     */       try {
/* 265 */         this.available.acquire(this.size);
/*     */         try {
/* 267 */           RandomAccessFile file = (RandomAccessFile)this.files.poll();
/* 268 */           while (file != null) {
/* 269 */             file.close();
/* 270 */             file = (RandomAccessFile)this.files.poll();
/*     */           }
/*     */         }
/*     */         finally {
/* 274 */           this.available.release(this.size);
/*     */         }
/*     */       }
/*     */       catch (InterruptedException ex) {
/* 278 */         throw new IOException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\data\RandomAccessDataFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */