/*    */ package org.springframework.boot.loader.jar;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.springframework.boot.loader.data.RandomAccessData;
/*    */ import org.springframework.boot.loader.data.RandomAccessData.ResourceAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Bytes
/*    */ {
/* 32 */   private static final byte[] EMPTY_BYTES = new byte[0];
/*    */   
/*    */   public static byte[] get(RandomAccessData data) throws IOException {
/* 35 */     InputStream inputStream = data.getInputStream(RandomAccessData.ResourceAccess.ONCE);
/*    */     try {
/* 37 */       return get(inputStream, data.getSize());
/*    */     }
/*    */     finally {
/* 40 */       inputStream.close();
/*    */     }
/*    */   }
/*    */   
/*    */   public static byte[] get(InputStream inputStream, long length) throws IOException {
/* 45 */     if (length == 0L) {
/* 46 */       return EMPTY_BYTES;
/*    */     }
/* 48 */     byte[] bytes = new byte[(int)length];
/* 49 */     if (!fill(inputStream, bytes)) {
/* 50 */       throw new IOException("Unable to read bytes");
/*    */     }
/* 52 */     return bytes;
/*    */   }
/*    */   
/*    */   public static boolean fill(InputStream inputStream, byte[] bytes) throws IOException {
/* 56 */     return fill(inputStream, bytes, 0, bytes.length);
/*    */   }
/*    */   
/*    */   private static boolean fill(InputStream inputStream, byte[] bytes, int offset, int length) throws IOException
/*    */   {
/* 61 */     while (length > 0) {
/* 62 */       int read = inputStream.read(bytes, offset, length);
/* 63 */       if (read == -1) {
/* 64 */         return false;
/*    */       }
/* 66 */       offset += read;
/* 67 */       length = -read;
/*    */     }
/* 69 */     return true;
/*    */   }
/*    */   
/*    */   public static long littleEndianValue(byte[] bytes, int offset, int length) {
/* 73 */     long value = 0L;
/* 74 */     for (int i = length - 1; i >= 0; i--) {
/* 75 */       value = value << 8 | bytes[(offset + i)] & 0xFF;
/*    */     }
/* 77 */     return value;
/*    */   }
/*    */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\jar\Bytes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */