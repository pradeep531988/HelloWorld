/*     */ package org.springframework.boot.loader.jar;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Handler
/*     */   extends URLStreamHandler
/*     */ {
/*     */   private static final String FILE_PROTOCOL = "file:";
/*     */   private static final String SEPARATOR = "!/";
/*  48 */   private static final String[] FALLBACK_HANDLERS = { "sun.net.www.protocol.jar.Handler" };
/*     */   private static final Method OPEN_CONNECTION_METHOD;
/*     */   
/*     */   static {
/*  52 */     Method method = null;
/*     */     try {
/*  54 */       method = URLStreamHandler.class.getDeclaredMethod("openConnection", new Class[] { URL.class });
/*     */     }
/*     */     catch (Exception ex) {}
/*     */     
/*     */ 
/*  59 */     OPEN_CONNECTION_METHOD = method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  64 */   private static SoftReference<Map<File, JarFile>> rootFileCache = new SoftReference(null);
/*     */   
/*     */ 
/*  67 */   private final Logger logger = Logger.getLogger(getClass().getName());
/*     */   
/*     */   private final JarFile jarFile;
/*     */   private URLStreamHandler fallbackHandler;
/*     */   
/*     */   public Handler()
/*     */   {
/*  74 */     this(null);
/*     */   }
/*     */   
/*     */   public Handler(JarFile jarFile) {
/*  78 */     this.jarFile = jarFile;
/*     */   }
/*     */   
/*     */   protected URLConnection openConnection(URL url) throws IOException
/*     */   {
/*  83 */     if (this.jarFile != null) {
/*  84 */       return new JarURLConnection(url, this.jarFile);
/*     */     }
/*     */     try {
/*  87 */       return new JarURLConnection(url, getRootJarFileFromUrl(url));
/*     */     }
/*     */     catch (Exception ex) {
/*  90 */       return openFallbackConnection(url, ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private URLConnection openFallbackConnection(URL url, Exception reason) throws IOException
/*     */   {
/*     */     try {
/*  97 */       return openConnection(getFallbackHandler(), url);
/*     */     }
/*     */     catch (Exception ex) {
/* 100 */       if ((reason instanceof IOException)) {
/* 101 */         this.logger.log(Level.FINEST, "Unable to open fallback handler", ex);
/* 102 */         throw ((IOException)reason);
/*     */       }
/* 104 */       this.logger.log(Level.WARNING, "Unable to open fallback handler", ex);
/* 105 */       if ((reason instanceof RuntimeException)) {
/* 106 */         throw ((RuntimeException)reason);
/*     */       }
/* 108 */       throw new IllegalStateException(reason);
/*     */     }
/*     */   }
/*     */   
/*     */   private URLStreamHandler getFallbackHandler() {
/* 113 */     if (this.fallbackHandler != null) {
/* 114 */       return this.fallbackHandler;
/*     */     }
/* 116 */     for (String handlerClassName : FALLBACK_HANDLERS) {
/*     */       try {
/* 118 */         Class<?> handlerClass = Class.forName(handlerClassName);
/* 119 */         this.fallbackHandler = ((URLStreamHandler)handlerClass.newInstance());
/* 120 */         return this.fallbackHandler;
/*     */       }
/*     */       catch (Exception ex) {}
/*     */     }
/*     */     
/*     */ 
/* 126 */     throw new IllegalStateException("Unable to find fallback handler");
/*     */   }
/*     */   
/*     */   private URLConnection openConnection(URLStreamHandler handler, URL url) throws Exception
/*     */   {
/* 131 */     if (OPEN_CONNECTION_METHOD == null) {
/* 132 */       throw new IllegalStateException("Unable to invoke fallback open connection method");
/*     */     }
/*     */     
/* 135 */     OPEN_CONNECTION_METHOD.setAccessible(true);
/* 136 */     return (URLConnection)OPEN_CONNECTION_METHOD.invoke(handler, new Object[] { url });
/*     */   }
/*     */   
/*     */   public JarFile getRootJarFileFromUrl(URL url) throws IOException {
/* 140 */     String spec = url.getFile();
/* 141 */     int separatorIndex = spec.indexOf("!/");
/* 142 */     if (separatorIndex == -1) {
/* 143 */       throw new MalformedURLException("Jar URL does not contain !/ separator");
/*     */     }
/* 145 */     String name = spec.substring(0, separatorIndex);
/* 146 */     return getRootJarFile(name);
/*     */   }
/*     */   
/*     */   private JarFile getRootJarFile(String name) throws IOException {
/*     */     try {
/* 151 */       if (!name.startsWith("file:")) {
/* 152 */         throw new IllegalStateException("Not a file URL");
/*     */       }
/* 154 */       String path = name.substring("file:".length());
/* 155 */       File file = new File(URLDecoder.decode(path, "UTF-8"));
/* 156 */       Map<File, JarFile> cache = (Map)rootFileCache.get();
/* 157 */       JarFile jarFile = cache == null ? null : (JarFile)cache.get(file);
/* 158 */       if (jarFile == null) {
/* 159 */         jarFile = new JarFile(file);
/* 160 */         addToRootFileCache(file, jarFile);
/*     */       }
/* 162 */       return jarFile;
/*     */     }
/*     */     catch (Exception ex) {
/* 165 */       throw new IOException("Unable to open root Jar file '" + name + "'", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void addToRootFileCache(File sourceFile, JarFile jarFile)
/*     */   {
/* 175 */     Map<File, JarFile> cache = (Map)rootFileCache.get();
/* 176 */     if (cache == null) {
/* 177 */       cache = new ConcurrentHashMap();
/* 178 */       rootFileCache = new SoftReference(cache);
/*     */     }
/* 180 */     cache.put(sourceFile, jarFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setUseFastConnectionExceptions(boolean useFastConnectionExceptions)
/*     */   {
/* 190 */     JarURLConnection.setUseFastExceptions(useFastConnectionExceptions);
/*     */   }
/*     */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\jar\Handler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */