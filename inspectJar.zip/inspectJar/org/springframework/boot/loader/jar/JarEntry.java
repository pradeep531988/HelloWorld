/*    */ package org.springframework.boot.loader.jar;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import java.security.CodeSigner;
/*    */ import java.security.cert.Certificate;
/*    */ import java.util.jar.Attributes;
/*    */ import java.util.jar.Manifest;
/*    */ import org.springframework.boot.loader.util.AsciiBytes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarEntry
/*    */   extends java.util.jar.JarEntry
/*    */ {
/*    */   private final JarEntryData source;
/*    */   private Certificate[] certificates;
/*    */   private CodeSigner[] codeSigners;
/*    */   
/*    */   public JarEntry(JarEntryData source)
/*    */   {
/* 41 */     super(source.getName().toString());
/* 42 */     this.source = source;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public JarEntryData getSource()
/*    */   {
/* 50 */     return this.source;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public URL getUrl()
/*    */     throws MalformedURLException
/*    */   {
/* 59 */     return new URL(this.source.getSource().getUrl(), getName());
/*    */   }
/*    */   
/*    */   public Attributes getAttributes() throws IOException
/*    */   {
/* 64 */     Manifest manifest = this.source.getSource().getManifest();
/* 65 */     return manifest == null ? null : manifest.getAttributes(getName());
/*    */   }
/*    */   
/*    */   public Certificate[] getCertificates()
/*    */   {
/* 70 */     if ((this.source.getSource().isSigned()) && (this.certificates == null)) {
/* 71 */       this.source.getSource().setupEntryCertificates();
/*    */     }
/* 73 */     return this.certificates;
/*    */   }
/*    */   
/*    */   public CodeSigner[] getCodeSigners()
/*    */   {
/* 78 */     if ((this.source.getSource().isSigned()) && (this.codeSigners == null)) {
/* 79 */       this.source.getSource().setupEntryCertificates();
/*    */     }
/* 81 */     return this.codeSigners;
/*    */   }
/*    */   
/*    */   void setupCertificates(java.util.jar.JarEntry entry) {
/* 85 */     this.certificates = entry.getCertificates();
/* 86 */     this.codeSigners = entry.getCodeSigners();
/*    */   }
/*    */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\jar\JarEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */