/*     */ package org.springframework.boot.loader.jar;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.ref.SoftReference;
/*     */ import org.springframework.boot.loader.data.RandomAccessData;
/*     */ import org.springframework.boot.loader.data.RandomAccessData.ResourceAccess;
/*     */ import org.springframework.boot.loader.util.AsciiBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JarEntryData
/*     */ {
/*     */   private static final long LOCAL_FILE_HEADER_SIZE = 30L;
/*  38 */   private static final AsciiBytes SLASH = new AsciiBytes("/");
/*     */   
/*     */   private final JarFile source;
/*     */   
/*     */   private final byte[] header;
/*     */   
/*     */   private AsciiBytes name;
/*     */   
/*     */   private final byte[] extra;
/*     */   
/*     */   private final AsciiBytes comment;
/*     */   
/*     */   private final long localHeaderOffset;
/*     */   
/*     */   private RandomAccessData data;
/*     */   
/*     */   private SoftReference<JarEntry> entry;
/*     */   JarFile nestedJar;
/*     */   
/*     */   public JarEntryData(JarFile source, byte[] header, InputStream inputStream)
/*     */     throws IOException
/*     */   {
/*  60 */     this.source = source;
/*  61 */     this.header = header;
/*  62 */     long nameLength = Bytes.littleEndianValue(header, 28, 2);
/*  63 */     long extraLength = Bytes.littleEndianValue(header, 30, 2);
/*  64 */     long commentLength = Bytes.littleEndianValue(header, 32, 2);
/*  65 */     this.name = new AsciiBytes(Bytes.get(inputStream, nameLength));
/*  66 */     this.extra = Bytes.get(inputStream, extraLength);
/*  67 */     this.comment = new AsciiBytes(Bytes.get(inputStream, commentLength));
/*  68 */     this.localHeaderOffset = Bytes.littleEndianValue(header, 42, 4);
/*     */   }
/*     */   
/*     */   private JarEntryData(JarEntryData master, JarFile source, AsciiBytes name) {
/*  72 */     this.header = master.header;
/*  73 */     this.extra = master.extra;
/*  74 */     this.comment = master.comment;
/*  75 */     this.localHeaderOffset = master.localHeaderOffset;
/*  76 */     this.source = source;
/*  77 */     this.name = name;
/*     */   }
/*     */   
/*     */   void setName(AsciiBytes name) {
/*  81 */     this.name = name;
/*     */   }
/*     */   
/*     */   JarFile getSource() {
/*  85 */     return this.source;
/*     */   }
/*     */   
/*     */   InputStream getInputStream() throws IOException {
/*  89 */     InputStream inputStream = getData().getInputStream(RandomAccessData.ResourceAccess.PER_READ);
/*  90 */     if (getMethod() == 8) {
/*  91 */       inputStream = new ZipInflaterInputStream(inputStream, getSize());
/*     */     }
/*  93 */     return inputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RandomAccessData getData()
/*     */     throws IOException
/*     */   {
/* 103 */     if (this.data == null)
/*     */     {
/*     */ 
/*     */ 
/* 107 */       byte[] localHeader = Bytes.get(this.source.getData().getSubsection(this.localHeaderOffset, 30L));
/*     */       
/* 109 */       long nameLength = Bytes.littleEndianValue(localHeader, 26, 2);
/* 110 */       long extraLength = Bytes.littleEndianValue(localHeader, 28, 2);
/* 111 */       this.data = this.source.getData().getSubsection(this.localHeaderOffset + 30L + nameLength + extraLength, getCompressedSize());
/*     */     }
/*     */     
/*     */ 
/* 115 */     return this.data;
/*     */   }
/*     */   
/*     */   JarEntry asJarEntry() {
/* 119 */     JarEntry entry = this.entry == null ? null : (JarEntry)this.entry.get();
/* 120 */     if (entry == null) {
/* 121 */       entry = new JarEntry(this);
/* 122 */       entry.setCompressedSize(getCompressedSize());
/* 123 */       entry.setMethod(getMethod());
/* 124 */       entry.setCrc(getCrc());
/* 125 */       entry.setSize(getSize());
/* 126 */       entry.setExtra(getExtra());
/* 127 */       entry.setComment(getComment().toString());
/* 128 */       entry.setSize(getSize());
/* 129 */       entry.setTime(getTime());
/* 130 */       this.entry = new SoftReference(entry);
/*     */     }
/* 132 */     return entry;
/*     */   }
/*     */   
/*     */   public AsciiBytes getName() {
/* 136 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean isDirectory() {
/* 140 */     return this.name.endsWith(SLASH);
/*     */   }
/*     */   
/*     */   public int getMethod() {
/* 144 */     return (int)Bytes.littleEndianValue(this.header, 10, 2);
/*     */   }
/*     */   
/*     */   public long getTime() {
/* 148 */     return Bytes.littleEndianValue(this.header, 12, 4);
/*     */   }
/*     */   
/*     */   public long getCrc() {
/* 152 */     return Bytes.littleEndianValue(this.header, 16, 4);
/*     */   }
/*     */   
/*     */   public int getCompressedSize() {
/* 156 */     return (int)Bytes.littleEndianValue(this.header, 20, 4);
/*     */   }
/*     */   
/*     */   public int getSize() {
/* 160 */     return (int)Bytes.littleEndianValue(this.header, 24, 4);
/*     */   }
/*     */   
/*     */   public byte[] getExtra() {
/* 164 */     return this.extra;
/*     */   }
/*     */   
/*     */   public AsciiBytes getComment() {
/* 168 */     return this.comment;
/*     */   }
/*     */   
/*     */   JarEntryData createFilteredCopy(JarFile jarFile, AsciiBytes name) {
/* 172 */     return new JarEntryData(this, jarFile, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static JarEntryData fromInputStream(JarFile source, InputStream inputStream)
/*     */     throws IOException
/*     */   {
/* 184 */     byte[] header = new byte[46];
/* 185 */     if (!Bytes.fill(inputStream, header)) {
/* 186 */       return null;
/*     */     }
/* 188 */     return new JarEntryData(source, header, inputStream);
/*     */   }
/*     */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\jar\JarEntryData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */