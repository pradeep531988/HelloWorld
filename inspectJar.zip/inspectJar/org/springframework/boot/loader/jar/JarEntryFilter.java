package org.springframework.boot.loader.jar;

import org.springframework.boot.loader.util.AsciiBytes;

public abstract interface JarEntryFilter
{
  public abstract AsciiBytes apply(AsciiBytes paramAsciiBytes, JarEntryData paramJarEntryData);
}


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\jar\JarEntryFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */