/*     */ package org.springframework.boot.loader.jar;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.jar.JarInputStream;
/*     */ import java.util.jar.Manifest;
/*     */ import java.util.zip.ZipEntry;
/*     */ import org.springframework.boot.loader.data.RandomAccessData;
/*     */ import org.springframework.boot.loader.data.RandomAccessData.ResourceAccess;
/*     */ import org.springframework.boot.loader.data.RandomAccessDataFile;
/*     */ import org.springframework.boot.loader.util.AsciiBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarFile
/*     */   extends java.util.jar.JarFile
/*     */   implements Iterable<JarEntryData>
/*     */ {
/*  59 */   private static final AsciiBytes META_INF = new AsciiBytes("META-INF/");
/*     */   
/*  61 */   private static final AsciiBytes MANIFEST_MF = new AsciiBytes("META-INF/MANIFEST.MF");
/*     */   
/*  63 */   private static final AsciiBytes SIGNATURE_FILE_EXTENSION = new AsciiBytes(".SF");
/*     */   
/*     */   private static final String PROTOCOL_HANDLER = "java.protocol.handler.pkgs";
/*     */   
/*     */   private static final String HANDLERS_PACKAGE = "org.springframework.boot.loader";
/*     */   
/*  69 */   private static final AsciiBytes SLASH = new AsciiBytes("/");
/*     */   
/*     */ 
/*     */   private final RandomAccessDataFile rootFile;
/*     */   
/*     */ 
/*     */   private final String pathFromRoot;
/*     */   
/*     */   private final RandomAccessData data;
/*     */   
/*     */   private final List<JarEntryData> entries;
/*     */   
/*     */   private SoftReference<Map<AsciiBytes, JarEntryData>> entriesByName;
/*     */   
/*     */   private boolean signed;
/*     */   
/*     */   private JarEntryData manifestEntry;
/*     */   
/*     */   private SoftReference<Manifest> manifest;
/*     */   
/*     */   private URL url;
/*     */   
/*     */ 
/*     */   public JarFile(File file)
/*     */     throws IOException
/*     */   {
/*  95 */     this(new RandomAccessDataFile(file));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   JarFile(RandomAccessDataFile file)
/*     */     throws IOException
/*     */   {
/* 104 */     this(file, "", file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JarFile(RandomAccessDataFile rootFile, String pathFromRoot, RandomAccessData data)
/*     */     throws IOException
/*     */   {
/* 117 */     super(rootFile.getFile());
/* 118 */     CentralDirectoryEndRecord endRecord = new CentralDirectoryEndRecord(data);
/* 119 */     this.rootFile = rootFile;
/* 120 */     this.pathFromRoot = pathFromRoot;
/* 121 */     this.data = getArchiveData(endRecord, data);
/* 122 */     this.entries = loadJarEntries(endRecord);
/*     */   }
/*     */   
/*     */   private JarFile(RandomAccessDataFile rootFile, String pathFromRoot, RandomAccessData data, List<JarEntryData> entries, JarEntryFilter... filters)
/*     */     throws IOException
/*     */   {
/* 128 */     super(rootFile.getFile());
/* 129 */     this.rootFile = rootFile;
/* 130 */     this.pathFromRoot = pathFromRoot;
/* 131 */     this.data = data;
/* 132 */     this.entries = filterEntries(entries, filters);
/*     */   }
/*     */   
/*     */   private RandomAccessData getArchiveData(CentralDirectoryEndRecord endRecord, RandomAccessData data)
/*     */   {
/* 137 */     long offset = endRecord.getStartOfArchive(data);
/* 138 */     if (offset == 0L) {
/* 139 */       return data;
/*     */     }
/* 141 */     return data.getSubsection(offset, data.getSize() - offset);
/*     */   }
/*     */   
/*     */   private List<JarEntryData> loadJarEntries(CentralDirectoryEndRecord endRecord) throws IOException
/*     */   {
/* 146 */     RandomAccessData centralDirectory = endRecord.getCentralDirectory(this.data);
/* 147 */     int numberOfRecords = endRecord.getNumberOfRecords();
/* 148 */     List<JarEntryData> entries = new ArrayList(numberOfRecords);
/* 149 */     InputStream inputStream = centralDirectory.getInputStream(RandomAccessData.ResourceAccess.ONCE);
/*     */     try {
/* 151 */       JarEntryData entry = JarEntryData.fromInputStream(this, inputStream);
/* 152 */       while (entry != null) {
/* 153 */         entries.add(entry);
/* 154 */         processEntry(entry);
/* 155 */         entry = JarEntryData.fromInputStream(this, inputStream);
/*     */       }
/*     */     }
/*     */     finally {
/* 159 */       inputStream.close();
/*     */     }
/* 161 */     return entries;
/*     */   }
/*     */   
/*     */   private List<JarEntryData> filterEntries(List<JarEntryData> entries, JarEntryFilter[] filters)
/*     */   {
/* 166 */     List<JarEntryData> filteredEntries = new ArrayList(entries.size());
/* 167 */     for (JarEntryData entry : entries) {
/* 168 */       AsciiBytes name = entry.getName();
/* 169 */       for (JarEntryFilter filter : filters) {
/* 170 */         name = (filter == null) || (name == null) ? name : filter.apply(name, entry);
/*     */       }
/* 172 */       if (name != null) {
/* 173 */         JarEntryData filteredCopy = entry.createFilteredCopy(this, name);
/* 174 */         filteredEntries.add(filteredCopy);
/* 175 */         processEntry(filteredCopy);
/*     */       }
/*     */     }
/* 178 */     return filteredEntries;
/*     */   }
/*     */   
/*     */   private void processEntry(JarEntryData entry) {
/* 182 */     AsciiBytes name = entry.getName();
/* 183 */     if (name.startsWith(META_INF)) {
/* 184 */       processMetaInfEntry(name, entry);
/*     */     }
/*     */   }
/*     */   
/*     */   private void processMetaInfEntry(AsciiBytes name, JarEntryData entry) {
/* 189 */     if (name.equals(MANIFEST_MF)) {
/* 190 */       this.manifestEntry = entry;
/*     */     }
/* 192 */     if (name.endsWith(SIGNATURE_FILE_EXTENSION)) {
/* 193 */       this.signed = true;
/*     */     }
/*     */   }
/*     */   
/*     */   protected final RandomAccessDataFile getRootJarFile() {
/* 198 */     return this.rootFile;
/*     */   }
/*     */   
/*     */   RandomAccessData getData() {
/* 202 */     return this.data;
/*     */   }
/*     */   
/*     */   public Manifest getManifest() throws IOException
/*     */   {
/* 207 */     if (this.manifestEntry == null) {
/* 208 */       return null;
/*     */     }
/* 210 */     Manifest manifest = this.manifest == null ? null : (Manifest)this.manifest.get();
/* 211 */     if (manifest == null) {
/* 212 */       InputStream inputStream = this.manifestEntry.getInputStream();
/*     */       try {
/* 214 */         manifest = new Manifest(inputStream);
/*     */       }
/*     */       finally {
/* 217 */         inputStream.close();
/*     */       }
/* 219 */       this.manifest = new SoftReference(manifest);
/*     */     }
/* 221 */     return manifest;
/*     */   }
/*     */   
/*     */   public Enumeration<java.util.jar.JarEntry> entries()
/*     */   {
/* 226 */     final Iterator<JarEntryData> iterator = iterator();
/* 227 */     new Enumeration()
/*     */     {
/*     */       public boolean hasMoreElements()
/*     */       {
/* 231 */         return iterator.hasNext();
/*     */       }
/*     */       
/*     */       public java.util.jar.JarEntry nextElement()
/*     */       {
/* 236 */         return ((JarEntryData)iterator.next()).asJarEntry();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public Iterator<JarEntryData> iterator()
/*     */   {
/* 243 */     return this.entries.iterator();
/*     */   }
/*     */   
/*     */   public JarEntry getJarEntry(String name)
/*     */   {
/* 248 */     return (JarEntry)getEntry(name);
/*     */   }
/*     */   
/*     */   public ZipEntry getEntry(String name)
/*     */   {
/* 253 */     JarEntryData jarEntryData = getJarEntryData(name);
/* 254 */     return jarEntryData == null ? null : jarEntryData.asJarEntry();
/*     */   }
/*     */   
/*     */   public JarEntryData getJarEntryData(String name) {
/* 258 */     if (name == null) {
/* 259 */       return null;
/*     */     }
/* 261 */     return getJarEntryData(new AsciiBytes(name));
/*     */   }
/*     */   
/*     */   public JarEntryData getJarEntryData(AsciiBytes name) {
/* 265 */     if (name == null) {
/* 266 */       return null;
/*     */     }
/* 268 */     Map<AsciiBytes, JarEntryData> entriesByName = this.entriesByName == null ? null : (Map)this.entriesByName.get();
/*     */     
/* 270 */     if (entriesByName == null) {
/* 271 */       entriesByName = new HashMap();
/* 272 */       for (JarEntryData entry : this.entries) {
/* 273 */         entriesByName.put(entry.getName(), entry);
/*     */       }
/* 275 */       this.entriesByName = new SoftReference(entriesByName);
/*     */     }
/*     */     
/*     */ 
/* 279 */     JarEntryData entryData = (JarEntryData)entriesByName.get(name);
/* 280 */     if ((entryData == null) && (!name.endsWith(SLASH))) {
/* 281 */       entryData = (JarEntryData)entriesByName.get(name.append(SLASH));
/*     */     }
/* 283 */     return entryData;
/*     */   }
/*     */   
/*     */   boolean isSigned() {
/* 287 */     return this.signed;
/*     */   }
/*     */   
/*     */   void setupEntryCertificates()
/*     */   {
/*     */     try
/*     */     {
/* 294 */       JarInputStream inputStream = new JarInputStream(getData().getInputStream(RandomAccessData.ResourceAccess.ONCE));
/*     */       try
/*     */       {
/* 297 */         java.util.jar.JarEntry entry = inputStream.getNextJarEntry();
/* 298 */         while (entry != null) {
/* 299 */           inputStream.closeEntry();
/* 300 */           JarEntry jarEntry = getJarEntry(entry.getName());
/* 301 */           if (jarEntry != null) {
/* 302 */             jarEntry.setupCertificates(entry);
/*     */           }
/* 304 */           entry = inputStream.getNextJarEntry();
/*     */         }
/*     */       }
/*     */       finally {
/* 308 */         inputStream.close();
/*     */       }
/*     */     }
/*     */     catch (IOException ex) {
/* 312 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized InputStream getInputStream(ZipEntry ze) throws IOException
/*     */   {
/* 318 */     return getContainedEntry(ze).getSource().getInputStream();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized JarFile getNestedJarFile(ZipEntry ze)
/*     */     throws IOException
/*     */   {
/* 328 */     return getNestedJarFile(getContainedEntry(ze).getSource());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized JarFile getNestedJarFile(JarEntryData sourceEntry)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 340 */       if (sourceEntry.nestedJar == null) {
/* 341 */         sourceEntry.nestedJar = createJarFileFromEntry(sourceEntry);
/*     */       }
/* 343 */       return sourceEntry.nestedJar;
/*     */     }
/*     */     catch (IOException ex) {
/* 346 */       throw new IOException("Unable to open nested jar file '" + sourceEntry.getName() + "'", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private JarFile createJarFileFromEntry(JarEntryData sourceEntry) throws IOException
/*     */   {
/* 352 */     if (sourceEntry.isDirectory()) {
/* 353 */       return createJarFileFromDirectoryEntry(sourceEntry);
/*     */     }
/* 355 */     return createJarFileFromFileEntry(sourceEntry);
/*     */   }
/*     */   
/*     */   private JarFile createJarFileFromDirectoryEntry(JarEntryData sourceEntry) throws IOException
/*     */   {
/* 360 */     final AsciiBytes sourceName = sourceEntry.getName();
/* 361 */     JarEntryFilter filter = new JarEntryFilter()
/*     */     {
/*     */       public AsciiBytes apply(AsciiBytes name, JarEntryData entryData) {
/* 364 */         if ((name.startsWith(sourceName)) && (!name.equals(sourceName))) {
/* 365 */           return name.substring(sourceName.length());
/*     */         }
/* 367 */         return null;
/*     */       }
/* 369 */     };
/* 370 */     return new JarFile(this.rootFile, this.pathFromRoot + "!/" + sourceEntry.getName().substring(0, sourceName.length() - 1), this.data, this.entries, new JarEntryFilter[] { filter });
/*     */   }
/*     */   
/*     */ 
/*     */   private JarFile createJarFileFromFileEntry(JarEntryData sourceEntry)
/*     */     throws IOException
/*     */   {
/* 377 */     if (sourceEntry.getMethod() != 0) {
/* 378 */       throw new IllegalStateException("Unable to open nested entry '" + sourceEntry.getName() + "'. It has been compressed and nested " + "jar files must be stored without compression. Please check the " + "mechanism used to create your executable jar file");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 383 */     return new JarFile(this.rootFile, this.pathFromRoot + "!/" + sourceEntry.getName(), sourceEntry.getData());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized JarFile getFilteredJarFile(JarEntryFilter... filters)
/*     */     throws IOException
/*     */   {
/* 395 */     return new JarFile(this.rootFile, this.pathFromRoot, this.data, this.entries, filters);
/*     */   }
/*     */   
/*     */   private JarEntry getContainedEntry(ZipEntry zipEntry) throws IOException
/*     */   {
/* 400 */     if (((zipEntry instanceof JarEntry)) && (((JarEntry)zipEntry).getSource().getSource() == this))
/*     */     {
/* 402 */       return (JarEntry)zipEntry;
/*     */     }
/* 404 */     throw new IllegalArgumentException("ZipEntry must be contained in this file");
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/* 409 */     return (int)this.data.getSize();
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 414 */     this.rootFile.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getUrl()
/*     */     throws MalformedURLException
/*     */   {
/* 424 */     if (this.url == null) {
/* 425 */       Handler handler = new Handler(this);
/* 426 */       String file = this.rootFile.getFile().toURI() + this.pathFromRoot + "!/";
/* 427 */       file = file.replace("file:////", "file://");
/* 428 */       this.url = new URL("jar", "", -1, file, handler);
/*     */     }
/* 430 */     return this.url;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 435 */     return getName();
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 440 */     String path = this.pathFromRoot;
/* 441 */     return this.rootFile.getFile() + path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerUrlProtocolHandler()
/*     */   {
/* 449 */     String handlers = System.getProperty("java.protocol.handler.pkgs");
/* 450 */     System.setProperty("java.protocol.handler.pkgs", handlers + "|" + "org.springframework.boot.loader");
/*     */     
/* 452 */     resetCachedUrlHandlers();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void resetCachedUrlHandlers()
/*     */   {
/*     */     try
/*     */     {
/* 462 */       URL.setURLStreamHandlerFactory(null);
/*     */     }
/*     */     catch (Error ex) {}
/*     */   }
/*     */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\jar\JarFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */