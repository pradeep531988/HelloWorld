/*     */ package org.springframework.boot.loader.jar;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.util.jar.Manifest;
/*     */ import org.springframework.boot.loader.util.AsciiBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JarURLConnection
/*     */   extends java.net.JarURLConnection
/*     */ {
/*  38 */   private static final FileNotFoundException FILE_NOT_FOUND_EXCEPTION = new FileNotFoundException();
/*     */   private static final String SEPARATOR = "!/";
/*     */   private static final URL EMPTY_JAR_URL;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  46 */       EMPTY_JAR_URL = new URL("jar:", null, 0, "file:!/", new URLStreamHandler()
/*     */       {
/*     */         protected URLConnection openConnection(URL u)
/*     */           throws IOException
/*     */         {
/*  51 */           return null;
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (MalformedURLException ex) {
/*  56 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*  60 */   private static final JarEntryName EMPTY_JAR_ENTRY_NAME = new JarEntryName("");
/*     */   
/*  62 */   private static ThreadLocal<Boolean> useFastExceptions = new ThreadLocal();
/*     */   
/*     */   private final JarFile jarFile;
/*     */   
/*     */   private JarEntryData jarEntryData;
/*     */   
/*     */   private URL jarFileUrl;
/*     */   private JarEntryName jarEntryName;
/*     */   
/*     */   protected JarURLConnection(URL url, JarFile jarFile)
/*     */     throws IOException
/*     */   {
/*  74 */     super(EMPTY_JAR_URL);
/*  75 */     this.url = url;
/*  76 */     String spec = url.getFile().substring(jarFile.getUrl().getFile().length());
/*     */     int separator;
/*  78 */     while ((separator = spec.indexOf("!/")) > 0) {
/*  79 */       jarFile = getNestedJarFile(jarFile, spec.substring(0, separator));
/*  80 */       spec = spec.substring(separator + "!/".length());
/*     */     }
/*  82 */     this.jarFile = jarFile;
/*  83 */     this.jarEntryName = getJarEntryName(spec);
/*     */   }
/*     */   
/*     */   private JarFile getNestedJarFile(JarFile jarFile, String name) throws IOException {
/*  87 */     JarEntry jarEntry = jarFile.getJarEntry(name);
/*  88 */     if (jarEntry == null) {
/*  89 */       throwFileNotFound(jarEntry, jarFile);
/*     */     }
/*  91 */     return jarFile.getNestedJarFile(jarEntry);
/*     */   }
/*     */   
/*     */   private JarEntryName getJarEntryName(String spec) {
/*  95 */     if (spec.length() == 0) {
/*  96 */       return EMPTY_JAR_ENTRY_NAME;
/*     */     }
/*  98 */     return new JarEntryName(spec);
/*     */   }
/*     */   
/*     */   public void connect() throws IOException
/*     */   {
/* 103 */     if (!this.jarEntryName.isEmpty()) {
/* 104 */       this.jarEntryData = this.jarFile.getJarEntryData(this.jarEntryName.asAsciiBytes());
/*     */       
/* 106 */       if (this.jarEntryData == null) {
/* 107 */         throwFileNotFound(this.jarEntryName, this.jarFile);
/*     */       }
/*     */     }
/* 110 */     this.connected = true;
/*     */   }
/*     */   
/*     */   private void throwFileNotFound(Object entry, JarFile jarFile) throws FileNotFoundException
/*     */   {
/* 115 */     if (Boolean.TRUE.equals(useFastExceptions.get())) {
/* 116 */       throw FILE_NOT_FOUND_EXCEPTION;
/*     */     }
/* 118 */     throw new FileNotFoundException("JAR entry " + entry + " not found in " + jarFile.getName());
/*     */   }
/*     */   
/*     */   public Manifest getManifest() throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 125 */       return super.getManifest();
/*     */     }
/*     */     finally {
/* 128 */       this.connected = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public JarFile getJarFile() throws IOException
/*     */   {
/* 134 */     connect();
/* 135 */     return this.jarFile;
/*     */   }
/*     */   
/*     */   public URL getJarFileURL()
/*     */   {
/* 140 */     if (this.jarFileUrl == null) {
/* 141 */       this.jarFileUrl = buildJarFileUrl();
/*     */     }
/* 143 */     return this.jarFileUrl;
/*     */   }
/*     */   
/*     */   private URL buildJarFileUrl() {
/*     */     try {
/* 148 */       String spec = this.jarFile.getUrl().getFile();
/* 149 */       if (spec.endsWith("!/")) {
/* 150 */         spec = spec.substring(0, spec.length() - "!/".length());
/*     */       }
/* 152 */       if (spec.indexOf("!/") == -1) {
/* 153 */         return new URL(spec);
/*     */       }
/* 155 */       return new URL("jar:" + spec);
/*     */     }
/*     */     catch (MalformedURLException ex) {
/* 158 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public JarEntry getJarEntry() throws IOException
/*     */   {
/* 164 */     connect();
/* 165 */     return this.jarEntryData == null ? null : this.jarEntryData.asJarEntry();
/*     */   }
/*     */   
/*     */   public String getEntryName()
/*     */   {
/* 170 */     return this.jarEntryName.toString();
/*     */   }
/*     */   
/*     */   public InputStream getInputStream() throws IOException
/*     */   {
/* 175 */     connect();
/* 176 */     if (this.jarEntryName.isEmpty()) {
/* 177 */       throw new IOException("no entry name specified");
/*     */     }
/* 179 */     return this.jarEntryData.getInputStream();
/*     */   }
/*     */   
/*     */   public int getContentLength()
/*     */   {
/*     */     try {
/* 185 */       connect();
/* 186 */       if (this.jarEntryData != null) {
/* 187 */         return this.jarEntryData.getSize();
/*     */       }
/* 189 */       return this.jarFile.size();
/*     */     }
/*     */     catch (IOException ex) {}
/* 192 */     return -1;
/*     */   }
/*     */   
/*     */   public Object getContent()
/*     */     throws IOException
/*     */   {
/* 198 */     connect();
/* 199 */     return this.jarEntryData == null ? this.jarFile : super.getContent();
/*     */   }
/*     */   
/*     */   public String getContentType()
/*     */   {
/* 204 */     return this.jarEntryName.getContentType();
/*     */   }
/*     */   
/*     */   static void setUseFastExceptions(boolean useFastExceptions) {
/* 208 */     useFastExceptions.set(Boolean.valueOf(useFastExceptions));
/*     */   }
/*     */   
/*     */ 
/*     */   private static class JarEntryName
/*     */   {
/*     */     private final AsciiBytes name;
/*     */     
/*     */     private String contentType;
/*     */     
/*     */ 
/*     */     public JarEntryName(String spec)
/*     */     {
/* 221 */       this.name = decode(spec);
/*     */     }
/*     */     
/*     */     private AsciiBytes decode(String source) {
/* 225 */       int length = source == null ? 0 : source.length();
/* 226 */       if ((length == 0) || (source.indexOf('%') < 0)) {
/* 227 */         return new AsciiBytes(source);
/*     */       }
/* 229 */       ByteArrayOutputStream bos = new ByteArrayOutputStream(length);
/* 230 */       for (int i = 0; i < length; i++) {
/* 231 */         int ch = source.charAt(i);
/* 232 */         if (ch == 37) {
/* 233 */           if (i + 2 >= length) {
/* 234 */             throw new IllegalArgumentException("Invalid encoded sequence \"" + source.substring(i) + "\"");
/*     */           }
/*     */           
/* 237 */           ch = decodeEscapeSequence(source, i);
/* 238 */           i += 2;
/*     */         }
/* 240 */         bos.write(ch);
/*     */       }
/*     */       
/* 243 */       return new AsciiBytes(bos.toByteArray());
/*     */     }
/*     */     
/*     */     private char decodeEscapeSequence(String source, int i) {
/* 247 */       int hi = Character.digit(source.charAt(i + 1), 16);
/* 248 */       int lo = Character.digit(source.charAt(i + 2), 16);
/* 249 */       if ((hi == -1) || (lo == -1)) {
/* 250 */         throw new IllegalArgumentException("Invalid encoded sequence \"" + source.substring(i) + "\"");
/*     */       }
/*     */       
/* 253 */       return (char)((hi << 4) + lo);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 258 */       return this.name.toString();
/*     */     }
/*     */     
/*     */     public AsciiBytes asAsciiBytes() {
/* 262 */       return this.name;
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/* 266 */       return this.name.length() == 0;
/*     */     }
/*     */     
/*     */     public String getContentType() {
/* 270 */       if (this.contentType == null) {
/* 271 */         this.contentType = deduceContentType();
/*     */       }
/* 273 */       return this.contentType;
/*     */     }
/*     */     
/*     */     private String deduceContentType()
/*     */     {
/* 278 */       String type = isEmpty() ? "x-java/jar" : null;
/* 279 */       type = type != null ? type : URLConnection.guessContentTypeFromName(toString());
/* 280 */       type = type != null ? type : "content/unknown";
/* 281 */       return type;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\jar\JarURLConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */