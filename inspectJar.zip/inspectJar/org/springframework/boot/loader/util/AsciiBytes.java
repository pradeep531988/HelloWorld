/*     */ package org.springframework.boot.loader.util;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AsciiBytes
/*     */ {
/*  29 */   private static final Charset UTF_8 = Charset.forName("UTF-8");
/*     */   
/*     */ 
/*     */   private static final int INITIAL_HASH = 7;
/*     */   
/*     */ 
/*     */   private static final int MULTIPLIER = 31;
/*     */   
/*     */   private final byte[] bytes;
/*     */   
/*     */   private final int offset;
/*     */   
/*     */   private final int length;
/*     */   
/*     */   private String string;
/*     */   
/*     */ 
/*     */   public AsciiBytes(String string)
/*     */   {
/*  48 */     this(string.getBytes(UTF_8));
/*  49 */     this.string = string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsciiBytes(byte[] bytes)
/*     */   {
/*  58 */     this(bytes, 0, bytes.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsciiBytes(byte[] bytes, int offset, int length)
/*     */   {
/*  69 */     if ((offset < 0) || (length < 0) || (offset + length > bytes.length)) {
/*  70 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  72 */     this.bytes = bytes;
/*  73 */     this.offset = offset;
/*  74 */     this.length = length;
/*     */   }
/*     */   
/*     */   public int length() {
/*  78 */     return this.length;
/*     */   }
/*     */   
/*     */   public boolean startsWith(AsciiBytes prefix) {
/*  82 */     if (this == prefix) {
/*  83 */       return true;
/*     */     }
/*  85 */     if (prefix.length > this.length) {
/*  86 */       return false;
/*     */     }
/*  88 */     for (int i = 0; i < prefix.length; i++) {
/*  89 */       if (this.bytes[(i + this.offset)] != prefix.bytes[(i + prefix.offset)]) {
/*  90 */         return false;
/*     */       }
/*     */     }
/*  93 */     return true;
/*     */   }
/*     */   
/*     */   public boolean endsWith(AsciiBytes postfix) {
/*  97 */     if (this == postfix) {
/*  98 */       return true;
/*     */     }
/* 100 */     if (postfix.length > this.length) {
/* 101 */       return false;
/*     */     }
/* 103 */     for (int i = 0; i < postfix.length; i++) {
/* 104 */       if (this.bytes[(this.offset + (this.length - 1) - i)] != postfix.bytes[(postfix.offset + (postfix.length - 1) - i)])
/*     */       {
/* 106 */         return false;
/*     */       }
/*     */     }
/* 109 */     return true;
/*     */   }
/*     */   
/*     */   public AsciiBytes substring(int beginIndex) {
/* 113 */     return substring(beginIndex, this.length);
/*     */   }
/*     */   
/*     */   public AsciiBytes substring(int beginIndex, int endIndex) {
/* 117 */     int length = endIndex - beginIndex;
/* 118 */     if (this.offset + length > this.length) {
/* 119 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 121 */     return new AsciiBytes(this.bytes, this.offset + beginIndex, length);
/*     */   }
/*     */   
/*     */   public AsciiBytes append(String string) {
/* 125 */     if ((string == null) || (string.length() == 0)) {
/* 126 */       return this;
/*     */     }
/* 128 */     return append(string.getBytes(UTF_8));
/*     */   }
/*     */   
/*     */   public AsciiBytes append(AsciiBytes asciiBytes) {
/* 132 */     if ((asciiBytes == null) || (asciiBytes.length() == 0)) {
/* 133 */       return this;
/*     */     }
/* 135 */     return append(asciiBytes.bytes);
/*     */   }
/*     */   
/*     */   public AsciiBytes append(byte[] bytes) {
/* 139 */     if ((bytes == null) || (bytes.length == 0)) {
/* 140 */       return this;
/*     */     }
/* 142 */     byte[] combined = new byte[this.length + bytes.length];
/* 143 */     System.arraycopy(this.bytes, this.offset, combined, 0, this.length);
/* 144 */     System.arraycopy(bytes, 0, combined, this.length, bytes.length);
/* 145 */     return new AsciiBytes(combined);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 150 */     if (this.string == null) {
/* 151 */       this.string = new String(this.bytes, this.offset, this.length, UTF_8);
/*     */     }
/* 153 */     return this.string;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 158 */     int hash = 7;
/* 159 */     for (int i = 0; i < this.length; i++) {
/* 160 */       hash = 31 * hash + this.bytes[(this.offset + i)];
/*     */     }
/* 162 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 168 */     if (obj == null) {
/* 169 */       return false;
/*     */     }
/* 171 */     if (this == obj) {
/* 172 */       return true;
/*     */     }
/* 174 */     if (obj.getClass().equals(AsciiBytes.class)) {
/* 175 */       AsciiBytes other = (AsciiBytes)obj;
/* 176 */       if (this.length == other.length) {
/* 177 */         for (int i = 0; i < this.length; i++) {
/* 178 */           if (this.bytes[(this.offset + i)] != other.bytes[(other.offset + i)]) {
/* 179 */             return false;
/*     */           }
/*     */         }
/* 182 */         return true;
/*     */       }
/*     */     }
/* 185 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\apps\traveler-booking-path-generator copy\target\error-inspect\inspect.jar!\org\springframework\boot\loader\util\AsciiBytes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */